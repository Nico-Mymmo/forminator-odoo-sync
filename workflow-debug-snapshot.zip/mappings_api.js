/**
 * API endpoints for managing form mappings
 * Requires authentication
 * 
 * REFACTORED: Now uses Supabase PostgreSQL instead of Cloudflare KV
 * 
 * CANONICAL SERIALIZATION CONTRACT (LOCKED):
 * All dynamic workflow values MUST be strings containing ONLY:
 * - Plain text
 * - ${namespace.field} tokens where:
 *   - namespace ∈ {"field"} ∪ {known step names}
 *   - field = [A-Za-z0-9_]+
 * 
 * FORBIDDEN:
 * - JSON arrays: ["value"]
 * - JSON objects: {"key": "value"}
 * - Nested braces: ${{"nested"}}
 * - Bare tokens: ${field}
 * - Empty tokens: ${}
 * - Non-string types: null, undefined, number, boolean, object
 * 
 * CONTRACT ENFORCEMENT:
 * Backend rejects ALL invalid data with HTTP 400.
 * NO silent coercion, NO auto-fix, NO legacy support.
 */

import { Database } from '../lib/database.js';
import { invalidateMappingsCache } from '../config/form_mappings.js';

/**
 * Validate workflow value against canonical contract
 * @param {any} value - The value to validate
 * @param {string} context - Description of where this value came from (for error messages)
 * @throws {Error} If value violates contract
 */
function validateWorkflowValue(value, context) {
  // Type check: MUST be string
  if (typeof value !== 'string') {
    throw new Error(
      `CONTRACT VIOLATION at ${context}: ` +
      `Expected string, got ${typeof value}. ` +
      `Value: ${JSON.stringify(value)}`
    );
  }
  
  // Empty string is valid
  if (value === '') {
    return;
  }
  
  // Structural check: NO arrays or objects
  if (value.includes('[') || value.includes(']')) {
    throw new Error(
      `CONTRACT VIOLATION at ${context}: ` +
      `Found forbidden character '[' or ']' (JSON array syntax). ` +
      `Value: ${value}`
    );
  }
  
  // Check for nested braces (but allow ${...})
  const withoutTokens = value.replace(/\$\{[^}]*\}/g, '');
  if (withoutTokens.includes('{') || withoutTokens.includes('}')) {
    throw new Error(
      `CONTRACT VIOLATION at ${context}: ` +
      `Found forbidden character '{' or '}' outside of \${...} tokens. ` +
      `Value: ${value}`
    );
  }
  
  // Token validation: ALL tokens MUST match ${namespace.field}
  const tokenRegex = /\$\{([^}]+)\}/g;
  let match;
  
  while ((match = tokenRegex.exec(value)) !== null) {
    const token = match[1]; // Content inside ${}
    
    // MUST contain exactly one dot
    const parts = token.split('.');
    if (parts.length !== 2) {
      throw new Error(
        `CONTRACT VIOLATION at ${context}: ` +
        `Token '\${${token}}' must have format '\${namespace.field}'. ` +
        `Value: ${value}`
      );
    }
    
    const [namespace, field] = parts;
    
    // Namespace and field MUST be alphanumeric + underscore
    const validPattern = /^[A-Za-z0-9_]+$/;
    if (!validPattern.test(namespace)) {
      throw new Error(
        `CONTRACT VIOLATION at ${context}: ` +
        `Namespace '${namespace}' in token '\${${token}}' contains invalid characters. ` +
        `Only [A-Za-z0-9_] allowed. Value: ${value}`
      );
    }
    
    if (!validPattern.test(field)) {
      throw new Error(
        `CONTRACT VIOLATION at ${context}: ` +
        `Field '${field}' in token '\${${token}}' contains invalid characters. ` +
        `Only [A-Za-z0-9_] allowed. Value: ${value}`
      );
    }
  }
}

/**
 * Validate entire workflow data structure
 * Recursively validates all dynamic values in workflow steps
 * @param {Object} data - The mapping data object
 * @throws {Error} If any value violates contract
 */
function validateMappingData(data) {
  if (!data) {
    return;
  }
  
  // Validate workflow array
  if (data.workflow && Array.isArray(data.workflow)) {
    data.workflow.forEach((step, stepIdx) => {
      if (!step) return;
      
      const stepName = step.name || `step_${stepIdx}`;
      
      // Validate action-specific fields
      if (step.action === 'create') {
        if (step.values && Array.isArray(step.values)) {
          step.values.forEach((valueObj, valueIdx) => {
            if (valueObj && valueObj.value !== undefined) {
              validateWorkflowValue(
                valueObj.value,
                `workflow[${stepIdx}].values[${valueIdx}].value (step: ${stepName})`
              );
            }
          });
        }
      }
      
      if (step.action === 'update') {
        if (step.values && Array.isArray(step.values)) {
          step.values.forEach((valueObj, valueIdx) => {
            if (valueObj && valueObj.value !== undefined) {
              validateWorkflowValue(
                valueObj.value,
                `workflow[${stepIdx}].values[${valueIdx}].value (step: ${stepName})`
              );
            }
          });
        }
      }
      
      if (step.action === 'search') {
        if (step.domain && Array.isArray(step.domain)) {
          step.domain.forEach((condition, condIdx) => {
            if (Array.isArray(condition) && condition.length >= 3) {
              // Odoo domain format: [field, operator, value]
              const value = condition[2];
              if (value !== undefined) {
                validateWorkflowValue(
                  value,
                  `workflow[${stepIdx}].domain[${condIdx}][2] (step: ${stepName})`
                );
              }
            }
          });
        }
      }
    });
  }
}

/**
 * Check if user is authenticated
 */
function requireAuth(user) {
  if (!user) {
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Unauthorized' 
    }), {
      status: 401,
      headers: { 'Content-Type': 'application/json' }
    });
  }
  return null;
}

/**
 * Get all mappings
 * GET /api/mappings
 */
export async function getMappings({ env, user }) {
  const authError = requireAuth(user);
  if (authError) return authError;
  
  try {
    const db = new Database(env);
    const mappingsJson = await db.formMappings.getAllMappings();
    
    // Return mappings directly without wrapper (backwards compatible format)
    return new Response(JSON.stringify(mappingsJson), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error fetching mappings:', error);
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

/**
 * Get specific form mapping
 * GET /api/mappings/:formId
 */
export async function getMapping({ env, formId, user }) {
  const authError = requireAuth(user);
  if (authError) return authError;
  
  try {
    const db = new Database(env);
    const mapping = await db.formMappings.getMapping(formId);
    
    if (!mapping) {
      return new Response(JSON.stringify({
        success: false,
        error: `Form ${formId} not found`
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    return new Response(JSON.stringify({
      success: true,
      data: mapping
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error fetching mapping:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

/**
 * Save or update form mapping
 * POST /api/mappings/:formId
 * Body: { name, field_mapping, value_mapping, html_card, workflow, _version }
 * 
 * _version is optional - if provided, enables optimistic locking
 */
export async function saveMapping({ env, formId, data, user }) {
  const authError = requireAuth(user);
  if (authError) return authError;
  
  try {
    console.log(`🔵 [API saveMapping] formId: ${formId}`);
    console.log(`🔵 [API saveMapping] data.workflow length: ${data.workflow?.length}`);
    
    // VALIDATE DATA BEFORE SAVE
    try {
      validateMappingData(data);
      console.log(`✅ [API saveMapping] Validation passed for form ${formId}`);
    } catch (validationError) {
      console.error(`❌ [API saveMapping] Validation failed:`, validationError.message);
      return new Response(JSON.stringify({
        success: false,
        error: 'validation_failed',
        message: validationError.message
      }), {
        status: 400, // Bad Request
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    const db = new Database(env);
    const expectedVersion = data._version || null;
    
    // Check if mapping exists
    const existing = await db.formMappings.getMapping(formId);
    
    let savedMapping;
    
    if (!existing) {
      // Create new mapping
      savedMapping = await db.formMappings.createMapping(formId, data);
      console.log(`✅ Created new mapping for form ${formId}`);
    } else {
      // Update existing mapping with optimistic locking
      try {
        savedMapping = await db.formMappings.updateMapping(
          formId, 
          data, 
          expectedVersion
        );
        console.log(`✅ Updated mapping for form ${formId} (version ${savedMapping._metadata.version})`);
      } catch (error) {
        if (error.code === 'VERSION_CONFLICT') {
          return new Response(JSON.stringify({
            success: false,
            error: 'conflict',
            message: error.message,
            currentVersion: error.currentVersion
          }), {
            status: 409, // Conflict
            headers: { 'Content-Type': 'application/json' }
          });
        }
        throw error;
      }
    }
    
    // Invalidate cache to ensure fresh data
    invalidateMappingsCache();
    
    return new Response(JSON.stringify({
      success: true,
      message: `Form ${formId} mapping saved`,
      data: savedMapping
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error saving mapping:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

/**
 * Delete form mapping (soft delete)
 * DELETE /api/mappings/:formId
 */
export async function deleteMapping({ env, formId, user }) {
  const authError = requireAuth(user);
  if (authError) return authError;
  
  try {
    const db = new Database(env);
    
    // Check if exists
    const existing = await db.formMappings.getMapping(formId);
    if (!existing) {
      return new Response(JSON.stringify({
        success: false,
        error: `Form ${formId} not found`
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    // Soft delete
    await db.formMappings.deleteMapping(formId);
    
    // Invalidate cache
    invalidateMappingsCache();
    
    console.log(`🗑️ Soft deleted mapping for form ${formId}`);
    
    return new Response(JSON.stringify({
      success: true,
      message: `Form ${formId} mapping deleted`
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error deleting mapping:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

/**
 * Import entire mappings JSON (bulk import)
 * POST /api/mappings/import
 * Body: { mappings: { "formId1": {...}, "formId2": {...} } }
 */
export async function importMappings({ env, data, user }) {
  const authError = requireAuth(user);
  if (authError) return authError;
  
  try {
    // Validate it's an object
    if (!data.mappings || typeof data.mappings !== 'object') {
      return new Response(JSON.stringify({
        success: false,
        error: 'Invalid mappings format'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    const db = new Database(env);
    const formIds = Object.keys(data.mappings);
    let imported = 0;
    let updated = 0;
    let errors = [];
    
    // Import each form mapping
    for (const formId of formIds) {
      try {
        const mapping = data.mappings[formId];
        
        // VALIDATE BEFORE IMPORT
        try {
          validateMappingData(mapping);
        } catch (validationError) {
          throw new Error(`Validation failed: ${validationError.message}`);
        }
        
        const existing = await db.formMappings.getMapping(formId);
        
        if (!existing) {
          await db.formMappings.createMapping(formId, mapping);
          imported++;
        } else {
          await db.formMappings.updateMapping(formId, mapping);
          updated++;
        }
      } catch (error) {
        console.error(`Failed to import form ${formId}:`, error);
        errors.push({ formId, error: error.message });
      }
    }
    
    // Invalidate cache
    invalidateMappingsCache();
    
    console.log(`📥 Imported ${imported} new, updated ${updated} existing mappings`);
    
    return new Response(JSON.stringify({
      success: true,
      message: `Imported ${imported} new and updated ${updated} existing form mappings`,
      imported,
      updated,
      errors: errors.length > 0 ? errors : undefined
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error importing mappings:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

/**
 * Get mapping history
 * GET /api/mappings/:formId/history
 */
export async function getMappingHistory({ env, formId, user }) {
  const authError = requireAuth(user);
  if (authError) return authError;
  
  try {
    const db = new Database(env);
    
    // Check if mapping exists
    const mapping = await db.formMappings.getMapping(formId);
    if (!mapping) {
      return new Response(JSON.stringify({
        success: false,
        error: `Form ${formId} not found`
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    const history = await db.formMappings.getHistory(formId, 100);
    
    return new Response(JSON.stringify({
      success: true,
      data: history
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error fetching mapping history:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

/**
 * Restore mapping from history
 * POST /api/mappings/:formId/restore
 * Body: { historyId: "uuid" }
 */
export async function restoreMappingFromHistory({ env, formId, data, user }) {
  const authError = requireAuth(user);
  if (authError) return authError;
  
  try {
    if (!data.historyId) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Missing historyId'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    const db = new Database(env);
    
    // Get the history snapshot BEFORE restoring
    const { data: historyRecord, error: historyError } = await db.supabase
      .from('form_mapping_history')
      .select('snapshot')
      .eq('id', data.historyId)
      .eq('form_id', formId)
      .single();
    
    if (historyError) {
      throw new Error(`Failed to fetch history record: ${historyError.message}`);
    }
    
    // VALIDATE SNAPSHOT BEFORE RESTORE
    try {
      validateMappingData(historyRecord.snapshot);
      console.log(`✅ [API restoreMapping] Validation passed for history ${data.historyId}`);
    } catch (validationError) {
      console.error(`❌ [API restoreMapping] Validation failed:`, validationError.message);
      return new Response(JSON.stringify({
        success: false,
        error: 'validation_failed',
        message: `Historic snapshot violates current contract: ${validationError.message}`
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    
    const restoredMapping = await db.formMappings.restoreFromHistory(formId, data.historyId);
    
    // Invalidate cache
    invalidateMappingsCache();
    
    console.log(`♻️ Restored mapping for form ${formId} from history ${data.historyId}`);
    
    return new Response(JSON.stringify({
      success: true,
      message: `Form ${formId} restored from history`,
      data: restoredMapping
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error restoring mapping:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
