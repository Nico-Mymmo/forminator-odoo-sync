
        let currentFormId = null;
        
        // Theme management
        function changeTheme(theme) {
            document.documentElement.setAttribute('data-theme', theme);
            localStorage.setItem('selectedTheme', theme);
        }
        
        function initTheme() {
            const savedTheme = localStorage.getItem('selectedTheme') || 'light';
            document.documentElement.setAttribute('data-theme', savedTheme);
            const selector = document.getElementById('themeSelector');
            if (selector) {
                selector.value = savedTheme;
            }
        }
        
        // Initialize theme on page load
        initTheme();
        let mappings = {};
        let fieldMapping = {};
        let valueMapping = {};
        let workflowSteps = [];
        let preservedCollapseStates = null;
        let draggedFieldName = null;
        let expandedValueMappings = {};
        let currentHtmlCardStepIdx = null;
        let htmlCardSelectedFields = [];
        let htmlCardSections = []; // Array of {type: 'field'|'title'|'divider', ...}
        let autoSaveTimeout = null;
        let uiStateTimeout = null;
        
        /**
         * Get a path to the currently focused element for restoration after re-render
         * @param {HTMLElement} element - The focused element
         * @returns {Object|null} Path object with selectors to find the element again
         */
        function getFocusPath(element) {
            if (!element || element === document.body) return null;
            
            // Build a path of identifiable attributes
            const path = {
                id: element.id || null,
                name: element.name || null,
                className: element.className || null,
                tagName: element.tagName,
                placeholder: element.placeholder || null,
                dataIndex: element.closest('[data-index]')?.dataset.index || null
            };
            
            return path;
        }
        
        /**
         * Try to restore focus to an element based on its path
         * @param {Object} path - Path object from getFocusPath
         */
        function restoreFocus(path) {
            if (!path) return;
            
            let element = null;
            
            // Try ID first (most specific)
            if (path.id) {
                element = document.getElementById(path.id);
            }
            
            // Try name + data-index combination
            if (!element && path.name && path.dataIndex !== null) {
                const step = document.querySelector(`[data-index="${path.dataIndex}"]`);
                element = step?.querySelector(`[name="${path.name}"]`);
            }
            
            // Try placeholder within same step
            if (!element && path.placeholder && path.dataIndex !== null) {
                const step = document.querySelector(`[data-index="${path.dataIndex}"]`);
                element = step?.querySelector(`[placeholder="${path.placeholder}"]`);
            }
            
            if (element && typeof element.focus === 'function') {
                // Use setTimeout to ensure DOM is ready
                setTimeout(() => {
                    try {
                        element.focus();
                    } catch (e) {
                        // Silently ignore focus errors
                    }
                }, 0);
            }
        }
        
        /**
         * Normalize placeholder syntax to ALWAYS use ${} format
         * Handles both step references (contact.id → ${contact.id}) and field references (email → ${field.email})
         * @param {string} value - The raw value from drag & drop or input
         * @returns {string} Normalized value with ${} syntax
         */
        function normalizePlaceholderSyntax(value) {
            if (!value || typeof value !== 'string') return value;
            
            // Already has ${} syntax - return as is
            if (value.includes('${')) return value;
            
            // Check if it's a step reference (contains dot: contact.id, lead.name)
            if (value.includes('.') && !value.includes('field.')) {
                return '${' + value + '}';
            }
            
            // Check if it already has field. prefix
            if (value.startsWith('field.')) {
                return '${' + value + '}';
            }
            
            // Plain field name - add field. prefix
            return '${field.' + value + '}';
        }
        
        // State persistence helpers
        function saveUIState(immediate = false) {
            // Debounce UI state saves unless immediate is true
            if (!immediate) {
                if (uiStateTimeout) clearTimeout(uiStateTimeout);
                uiStateTimeout = setTimeout(() => saveUIState(true), 100);
                return;
            }
            
            const state = JSON.parse(localStorage.getItem('adminUIState') || '{}');
            
            // Update current view
            state.currentFormId = currentFormId;
            state.lastView = currentFormId ? 'form' : (document.getElementById('editorTitle')?.textContent.includes('History') ? 'history' : null);
            
            // Save collapse state per form
            if (!state.formStates) state.formStates = {};
            if (currentFormId) {
                // Find all collapse checkboxes that are NOT checked (i.e., collapsed)
                const allCheckboxes = Array.from(document.querySelectorAll('.collapse input[type="checkbox"]'));
                const collapsedSections = allCheckboxes
                    .filter(checkbox => !checkbox.checked && checkbox.id) // Only unchecked ones with ID
                    .map(checkbox => checkbox.id);
                
                // Find active tab
                const activeTab = document.querySelector('input[name="main_tabs"]:checked');
                const activeTabIndex = activeTab ? Array.from(document.querySelectorAll('input[name="main_tabs"]')).indexOf(activeTab) : 0;
                
                state.formStates[currentFormId] = {
                    collapsedSections,
                    activeTabIndex
                };
            }
            
            localStorage.setItem('adminUIState', JSON.stringify(state));
        }
        
        function restoreUIState() {
            try {
                const stateJson = localStorage.getItem('adminUIState');
                if (!stateJson) return null;
                return JSON.parse(stateJson);
            } catch (e) {
                console.error('Failed to restore UI state:', e);
                return null;
            }
        }
        
        // Debounced auto-save function
        function debouncedAutoSave() {
            if (autoSaveTimeout) clearTimeout(autoSaveTimeout);
            
            // Show saving indicator
            updateSaveStatus('saving');
            
            autoSaveTimeout = setTimeout(() => {
                if (currentFormId) {
                    saveForm(true); // true = silent save (no success message)
                }
            }, 1000); // 1000ms debounce for smooth performance
        }
        
        function updateSaveStatus(status) {
            const indicator = document.getElementById('saveIndicator');
            if (!indicator) return;
            
            if (status === 'saving') {
                indicator.innerHTML = '<span class="loading loading-spinner loading-xs"></span> <span class="text-xs">Saving...</span>';
                indicator.className = 'flex items-center gap-1 text-warning';
            } else if (status === 'saved') {
                indicator.innerHTML = '✓ <span class="text-xs">Saved</span>';
                indicator.className = 'flex items-center gap-1 text-success';
                // Hide after 2 seconds
                setTimeout(() => {
                    indicator.innerHTML = '';
                }, 2000);
            } else if (status === 'error') {
                indicator.innerHTML = '⚠ <span class="text-xs">Error</span>';
                indicator.className = 'flex items-center gap-1 text-error';
            }
        }
        
        // Odoo Model Templates
        const ODOO_MODELS = {
            'res.partner': {
                name: '👤 Contact / Bedrijf',
                description: 'Contactpersoon of bedrijf',
                searchTemplates: {
                    'email': {
                        name: 'Opzoeken op email',
                        fields: { email: { label: 'Email veld', dropOnly: true } },
                        typeFilter: true,
                        buildDomain: (values, typeFilter) => {
                            const domain = [['email', '=', values.email]];
                            if (typeFilter === 'contact') domain.push(['is_company', '=', false]);
                            if (typeFilter === 'company') domain.push(['is_company', '=', true]);
                            return domain;
                        },
                        defaultFields: ['id', 'name', 'email', 'parent_id', 'is_company']
                    },
                    'id': {
                        name: 'Opzoeken op ID',
                        fields: { contactId: { label: 'Contact ID', dropOnly: true } },
                        typeFilter: false,
                        buildDomain: (values) => {
                            return [['id', '=', values.contactId]];
                        },
                        defaultFields: ['id', 'name', 'email', 'is_company']
                    },
                    'name': {
                        name: 'Opzoeken op naam',
                        fields: { name: { label: 'Naam veld', dropOnly: true } },
                        typeFilter: true,
                        buildDomain: (values, typeFilter) => {
                            const domain = [['name', '=', values.name]];
                            if (typeFilter === 'contact') domain.push(['is_company', '=', false]);
                            if (typeFilter === 'company') domain.push(['is_company', '=', true]);
                            return domain;
                        },
                        defaultFields: ['id', 'name', 'email', 'parent_id', 'is_company']
                    }
                }
            },
            'crm.lead': {
                name: '🎯 Lead / Opportunity',
                description: 'Verkoopkans of lead',
                searchTemplates: {
                    'partner': {
                        name: 'Opzoeken op contact',
                        fields: { partnerId: { label: 'Contact ID', dropOnly: true } },
                        typeFilter: false,
                        buildDomain: (values) => {
                            return [['partner_id', '=', values.partnerId]];
                        },
                        defaultFields: ['id', 'name', 'partner_id', 'type']
                    }
                }
            },
            'x_web_visitor': {
                name: '🌐 Web Visitor',
                description: 'Website bezoeker tracking',
                searchTemplates: {
                    'uuid': {
                        name: 'Opzoeken op UUID',
                        fields: { uuid: { label: 'UUID veld', dropOnly: true } },
                        typeFilter: false,
                        buildDomain: (values) => {
                            return [['x_studio_uuid', '=', values.uuid]];
                        },
                        defaultFields: ['id', 'x_studio_uuid', 'x_studio_email']
                    }
                }
            },
            'custom': {
                name: '⚙️ Aangepast model',
                description: 'Vrij in te vullen model (zoals nu)',
                searchTemplates: {}
            }
        };
        
        // Check if already logged in via cookie
        fetch('/api/auth/me', { credentials: 'include' })
            .then(r => r.json())
            .then(d => { if (d.user) showAdmin(); })
            .catch(() => {});
        
        function switchStepTab(stepIdx, panelIdx) {
            // Get all tabs and panels for this step
            const tabs = document.querySelectorAll(`[onclick*="switchStepTab(${stepIdx}"]`);
            const panels = document.querySelectorAll(`[data-step="${stepIdx}"]`);
            
            // Remove active from all tabs, add to clicked one
            tabs.forEach((tab, idx) => {
                if (idx === panelIdx) {
                    tab.classList.add('tab-active');
                } else {
                    tab.classList.remove('tab-active');
                }
            });
            
            // Hide all panels, show selected one
            panels.forEach((panel, idx) => {
                if (idx === panelIdx) {
                    panel.classList.remove('hidden');
                    panel.classList.add('active');
                } else {
                    panel.classList.add('hidden');
                    panel.classList.remove('active');
                }
            });
        }
        
        async function login() {
            const email = document.getElementById('emailInput').value;
            const password = document.getElementById('passwordInput').value;
            const errorDiv = document.getElementById('loginError');
            const errorMsg = document.getElementById('loginErrorMessage');
            
            if (!email || !password) {
                errorMsg.textContent = 'Please enter email and password';
                errorDiv.style.display = 'flex';
                return;
            }
            
            try {
                errorDiv.style.display = 'none';
                
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    credentials: 'include',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // Cookie-based auth, no token needed
                    showAdmin();
                } else {
                    errorMsg.textContent = result.error || 'Login failed';
                    errorDiv.style.display = 'flex';
                }
            } catch (err) {
                errorMsg.textContent = 'Connection error: ' + err.message;
                errorDiv.style.display = 'flex';
            }
        }
        
        async function logout() {
            try {
                await fetch('/api/auth/logout', {
                    method: 'POST',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            } catch (err) {
                console.error('Logout error:', err);
            }
            location.reload();
        }
        
        async function syncProdData() {
            if (!confirm('Sync production data to dev? This will overwrite local changes.')) {
                return;
            }
            
            try {
                showAlert('Syncing production data...', 'info');
                const res = await apiCall('/api/mappings/sync-prod', { method: 'POST' });
                const result = await res.json();
                
                if (result.success) {
                    showAlert(result.message, 'success');
                    await loadForms(); // Reload forms
                } else {
                    showAlert('Sync failed: ' + result.error, 'error');
                }
            } catch (err) {
                showAlert('Sync failed: ' + err.message, 'error');
            }
        }
        
        function showAdmin() {
            document.getElementById('loginScreen').style.display = 'none';
            document.getElementById('adminInterface').style.display = 'flex';
            loadForms();
        }
        
        async function apiCall(path, options = {}) {
            // Always use relative paths when working locally
            const res = await fetch(path, {
                ...options,
                credentials: 'include',
                headers: {
                    ...options.headers,
                    'Content-Type': 'application/json'
                }
            });
            if (res.status === 401) {
                // Don't auto-logout on 401, might be session issue
                console.warn('401 Unauthorized on:', path);
            }
            return res;
        }
        
        async function loadForms() {
            try {
                const res = await apiCall('/api/mappings');
                mappings = await res.json();
                const list = document.getElementById('formList');
                list.innerHTML = '';
                Object.keys(mappings).filter(k => !k.startsWith('_')).forEach(formId => {
                    const li = document.createElement('li');
                    const a = document.createElement('a');
                    const formName = mappings[formId]?.name || formId;
                    a.textContent = formName;
                    a.title = `ID: ${formId}`;
                    a.onclick = () => loadForm(formId);
                    if (formId === currentFormId) {
                        a.className = 'active';
                    }
                    li.appendChild(a);
                    list.appendChild(li);
                });
                
                // Restore previous UI state after forms are loaded
                const savedState = restoreUIState();
                if (savedState) {
                    if (savedState.lastView === 'history') {
                        showHistory();
                    } else if (savedState.currentFormId && mappings[savedState.currentFormId]) {
                        // Trigger click on the saved form (collapse state will be restored in loadForm)
                        const formLink = Array.from(list.querySelectorAll('a')).find(a => 
                            a.title === `ID: ${savedState.currentFormId}`
                        );
                        if (formLink) {
                            formLink.click();
                        }
                    }
                }
                
                // Add event listener to save state when collapsibles are toggled
                document.addEventListener('change', (e) => {
                    if (e.target.type === 'checkbox' && e.target.closest('.collapse')) {
                        saveUIState();
                    }
                    
                    // Save state when tab is changed
                    if (e.target.type === 'radio' && e.target.name === 'main_tabs') {
                        saveUIState();
                    }
                });
                
                // Auto-save on Enter key for all inputs
                document.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) {
                        // Don't trigger on buttons or specific exceptions
                        if (e.target.type !== 'button' && e.target.type !== 'submit' && !e.target.classList.contains('no-auto-save')) {
                            e.preventDefault(); // Prevent form submission
                            debouncedAutoSave();
                        }
                    }
                });
                
                // Auto-save on blur (when leaving field)
                document.addEventListener('blur', (e) => {
                    if ((e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') && 
                        !e.target.classList.contains('no-auto-save') && 
                        currentFormId) {
                        debouncedAutoSave();
                    }
                }, true); // Use capture phase to catch all blur events
            } catch (err) {
                showAlert('Failed to load forms: ' + err.message, 'error');
            }
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        // Show global history view
        function showHistory() {
            console.log('🔍 [DEBUG] showHistory() called');
            
            // Save state BEFORE switching (immediate)
            saveUIState(true);
            
            currentFormId = null;
            document.querySelectorAll('#formList a').forEach(a => a.classList.remove('active'));
            
            document.getElementById('editorTitle').textContent = '📜 Request History';
            const editorContent = document.getElementById('editorContent');
            editorContent.innerHTML = `
                <div class="flex items-center justify-between mb-4">
                    <button class="btn btn-sm btn-ghost" onclick="loadHistory()">
                        🔄 Refresh
                    </button>
                </div>
                
                <div class="alert alert-info mb-4">
                    <span class="text-sm">Alle inkomende formulieraanvragen worden hier getoond, inclusief formulieren die niet verder afgehandeld werden.</span>
                </div>
                
                <!-- Filters -->
                <div class="flex gap-2 mb-4">
                    <select id="historyStatusFilter" class="select select-sm select-bordered" onchange="filterHistory()">
                        <option value="">Alle statussen</option>
                        <option value="success">✅ Success</option>
                        <option value="error">❌ Error</option>
                        <option value="skipped">⏭️ Skipped</option>
                    </select>
                    
                    <select id="historyFormFilter" class="select select-sm select-bordered" onchange="filterHistory()">
                        <option value="">Alle formulieren</option>
                    </select>
                    
                    <input type="date" id="historyDateFilter" class="input input-sm input-bordered" onchange="filterHistory()">
                </div>
                
                <!-- History list -->
                <div id="historyList" class="space-y-2">
                    <div class="text-center py-8 text-base-content/60">Loading history...</div>
                </div>
            `;
            
            console.log('🔍 [DEBUG] About to call loadHistory()');
            loadHistory();
        }
        
        function loadForm(formId) {
            // Save state of current form BEFORE switching (immediate, no debounce)
            saveUIState(true);
            
            currentFormId = formId;
            document.querySelectorAll('#formList a').forEach(a => a.classList.remove('active'));
            event.target.classList.add('active');
            
            const data = mappings[formId];
            fieldMapping = JSON.parse(JSON.stringify(data.field_mapping || {}));
            
            // Normalize value_mapping: convert Odoo field names to Forminator field names
            const rawValueMapping = JSON.parse(JSON.stringify(data.value_mapping || {}));
            valueMapping = {};
            Object.entries(rawValueMapping).forEach(([key, mappings]) => {
                // Find the forminator field that maps to this odoo field
                const formField = Object.keys(fieldMapping).find(f => fieldMapping[f] === key);
                if (formField) {
                    valueMapping[formField] = mappings;
                } else {
                    // Keep original key if no mapping found
                    valueMapping[key] = mappings;
                }
            });
            
            workflowSteps = JSON.parse(JSON.stringify(data.workflow || []));
            
            // Restore custom domain conditions and field types from metadata
            workflowSteps.forEach(step => {
                // Restore custom domain with field types
                if (step.search?._customDomain) {
                    // _customDomain exists in saved data (new format)
                    if (step._ui_metadata?.custom_domain_types) {
                        step.search._customDomain = step.search._customDomain.map((condition, idx) => {
                            const fieldType = step._ui_metadata.custom_domain_types[idx] || 'text';
                            const value = typeof condition[2] === 'string' ? condition[2].trim() : condition[2];
                            return [condition[0], condition[1], value, fieldType];
                        });
                    } else {
                        // Add default type if missing
                        step.search._customDomain = step.search._customDomain.map(condition => {
                            if (condition.length === 3) {
                                return [...condition, 'text'];
                            }
                            return condition;
                        });
                    }
                } else if (step.model && ODOO_MODELS[step.model]?.searchTemplates && step.search?.domain) {
                    // OLD FORMAT: Migration from old data where domain contained everything
                    // Treat existing domain as custom domain (template values are in _templateConfig)
                    step.search._customDomain = [...step.search.domain];
                    
                    if (step._ui_metadata?.domain_types) {
                        step.search._customDomain = step.search._customDomain.map((condition, idx) => {
                            const fieldType = step._ui_metadata.domain_types[idx] || 'text';
                            const value = typeof condition[2] === 'string' ? condition[2].trim() : condition[2];
                            return [condition[0], condition[1], value, fieldType];
                        });
                    } else {
                        step.search._customDomain = step.search._customDomain.map(condition => {
                            if (condition.length === 3) {
                                return [...condition, 'text'];
                            }
                            return condition;
                        });
                    }
                } else {
                    // No custom domain
                    if (!step.search) step.search = {};
                    step.search._customDomain = [];
                }
                
                // Clean update field values
                if (step.update?.fields) {
                    Object.keys(step.update.fields).forEach(key => {
                        const value = step.update.fields[key];
                        if (typeof value === 'string') {
                            step.update.fields[key] = value.trim();
                        }
                    });
                }
                
                // Clean create field values
                if (step.create) {
                    Object.keys(step.create).forEach(key => {
                        const value = step.create[key];
                        if (typeof value === 'string') {
                            step.create[key] = value.trim();
                        }
                    });
                }
            });
            
            expandedValueMappings = {};
            
            const formName = data.name || formId;
            const escapedFormName = escapeHtml(data.name || '');
            const escapedFormId = escapeHtml(formId);
            const webhookUrl = `https://forminator-sync.openvme-odoo.workers.dev/?action=receive_forminator&token=openvmeform`;
            const escapedWebhookUrl = escapeHtml(webhookUrl);
            document.getElementById('editorTitle').textContent = `Edit: ${formName}`;
            document.getElementById('editorContent').innerHTML = `
                <!-- Form Details Card -->
                <div class="card bg-base-100 shadow rounded-box mb-4">
                    <div class="card-body">
                        <div class="grid grid-cols-2 gap-4">
                            <div class="form-control">
                                <label class="label"><span class="label-text font-semibold">Form Name</span></label>
                                <input type="text" id="formName" value="${escapedFormName}" placeholder="Enter a display name" class="input input-bordered" onchange="updateFormName()">
                            </div>
                            <div class="form-control">
                                <label class="label"><span class="label-text font-semibold">Forminator Form ID</span></label>
                                <input type="text" id="formId" value="${escapedFormId}" readonly class="input input-bordered input-disabled" title="Form ID cannot be changed">
                            </div>
                        </div>
                        <div class="form-control">
                            <label class="label">
                                <span class="label-text font-semibold">Webhook URL</span>
                                <span class="label-text-alt">Gebruik deze URL in Forminator webhook instellingen</span>
                            </label>
                            <div class="join w-full">
                                <input type="text" value="${escapedWebhookUrl}" readonly class="input input-bordered join-item flex-1 font-mono text-sm">
                                <button class="btn btn-primary join-item" onclick="copyWebhookUrl('${escapedWebhookUrl}')">
                                    📋 Kopieer
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- DaisyUI Radio Tabs Lifted with Tab Content -->
                <div role="tablist" class="tabs tabs-lifted">
                    <input type="radio" name="main_tabs" role="tab" class="tab whitespace-nowrap" aria-label="📋 Mapping" />
                    <div role="tabpanel" class="tab-content bg-base-100 border-base-300 rounded-box p-6 w-full">
                        <h3 class="text-lg font-bold mb-3">Field Mapping & Value Mapping</h3>
                        <div id="fieldMapping" class="space-y-2"></div>
                        <button class="btn btn-primary btn-sm mt-3" onclick="addFieldRow()">+ Add Field</button>
                    </div>
                    
                    <input type="radio" name="main_tabs" role="tab" class="tab whitespace-nowrap" aria-label="⚙️ Workflow" />
                    <div role="tabpanel" class="tab-content bg-base-100 border-base-300 rounded-box p-6 w-full">
                        <h3 class="text-lg font-bold mb-3">Workflow Steps</h3>
                        <div id="workflowSteps"></div>
                        <button class="btn btn-success btn-sm mt-3" onclick="addWorkflowStep()">+ Add Workflow Step</button>
                    </div>
                </div>
                
                <!-- Actions -->
                <div class="flex gap-2 mt-4">
                    <button class="btn btn-primary" onclick="saveForm()">Save Changes</button>
                    <button class="btn btn-outline" onclick="exportForm()">Export JSON</button>
                    <button class="btn btn-error btn-outline" onclick="deleteForm()">Delete Form</button>
                </div>
                
                <!-- HTML Card Editor Modal -->
                <dialog id="htmlCardModal" class="modal">
                    <div class="modal-box w-11/12 max-w-6xl max-h-[90vh] p-0 flex flex-col">
                        <div class="bg-base-200 p-4 border-b border-base-300 flex justify-between items-center">
                            <h3 class="font-bold text-lg">📋 HTML Card Builder</h3>
                            <button class="btn btn-sm btn-circle btn-ghost" onclick="closeHtmlCardEditor()">✕</button>
                        </div>
                        
                        <div class="flex-1 flex overflow-hidden">
                            <!-- Left: Templates & Config -->
                            <div class="w-80 bg-base-100 border-r border-base-300 overflow-y-auto p-4 space-y-4">
                                <!-- Template Selection -->
                                <div>
                                    <h4 class="font-semibold mb-2 flex items-center gap-2">
                                        <i data-lucide="layout-template" class="w-4 h-4"></i>
                                        Templates
                                    </h4>
                                    <div class="grid grid-cols-2 gap-2" id="htmlCardTemplates">
                                        <button class="btn btn-sm btn-outline" onclick="applyHtmlCardTemplate('contact')">
                                            👤 Contact
                                        </button>
                                        <button class="btn btn-sm btn-outline" onclick="applyHtmlCardTemplate('property')">
                                            🏢 Property
                                        </button>
                                        <button class="btn btn-sm btn-outline" onclick="applyHtmlCardTemplate('summary')">
                                            📊 Summary
                                        </button>
                                        <button class="btn btn-sm btn-outline" onclick="applyHtmlCardTemplate('detailed')">
                                            📝 Detailed
                                        </button>
                                        <button class="btn btn-sm btn-outline" onclick="applyHtmlCardTemplate('simple')">
                                            ⚡ Simple
                                        </button>
                                        <button class="btn btn-sm btn-outline" onclick="applyHtmlCardTemplate('blank')">
                                            📄 Blank
                                        </button>
                                    </div>
                                </div>
                                
                                <div class="divider my-2"></div>
                                
                                <!-- Field Selection -->
                                <div>
                                    <h4 class="font-semibold mb-2 flex items-center gap-2">
                                        <i data-lucide="list" class="w-4 h-4"></i>
                                        Content Builder
                                    </h4>
                                    <div class="text-xs text-base-content/60 mb-2">Build your card structure</div>
                                    
                                    <!-- Add Element Buttons -->
                                    <div class="space-y-2 mb-3">
                                        <button class="btn btn-xs btn-block btn-outline" onclick="addHtmlCardSection('title')">
                                            <i data-lucide="heading" class="w-3 h-3"></i>
                                            Add Title
                                        </button>
                                        <button class="btn btn-xs btn-block btn-outline" onclick="addHtmlCardSection('divider')">
                                            <i data-lucide="minus" class="w-3 h-3"></i>
                                            Add Divider
                                        </button>
                                        <button class="btn btn-xs btn-block btn-outline" onclick="addHtmlCardSection('text')">
                                            <i data-lucide="text" class="w-3 h-3"></i>
                                            Add Text
                                        </button>
                                        <button class="btn btn-xs btn-block btn-outline" onclick="addHtmlCardSection('columnBreak')">
                                            <i data-lucide="columns" class="w-3 h-3"></i>
                                            Start New Group
                                        </button>
                                    </div>
                                    
                                    <div class="divider my-2 text-xs">Fields</div>
                                    
                                    <div id="htmlCardFieldSelector" class="space-y-1 max-h-64 overflow-y-auto"></div>
                                </div>
                                
                                <div class="divider my-2"></div>
                                
                                <!-- Style Options -->
                                <div>
                                    <h4 class="font-semibold mb-2 flex items-center gap-2">
                                        <i data-lucide="palette" class="w-4 h-4"></i>
                                        Style
                                    </h4>
                                    <div class="text-xs text-base-content/60 mb-2">Use "Start New Group" to set columns for each section</div>
                                    <div class="divider my-1"></div>
                                    <div class="form-control">
                                        <label class="label cursor-pointer justify-start gap-2">
                                            <input type="checkbox" id="htmlCardCompact" class="checkbox checkbox-sm" onchange="updateHtmlCardPreview()">
                                            <span class="label-text text-sm">Compact layout</span>
                                        </label>
                                    </div>
                                    <div class="form-control">
                                        <label class="label cursor-pointer justify-start gap-2">
                                            <input type="checkbox" id="htmlCardBorders" class="checkbox checkbox-sm" checked onchange="updateHtmlCardPreview()">
                                            <span class="label-text text-sm">Show borders</span>
                                        </label>
                                    </div>
                                    <div class="form-control">
                                        <label class="label cursor-pointer justify-start gap-2">
                                            <input type="checkbox" id="htmlCardIcons" class="checkbox checkbox-sm" checked onchange="updateHtmlCardPreview()">
                                            <span class="label-text text-sm">Show icons</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Right: Preview -->
                            <div class="flex-1 bg-base-50 p-6 overflow-y-auto">
                                <div class="mb-3 flex items-center justify-between">
                                    <h4 class="font-semibold flex items-center gap-2">
                                        <i data-lucide="eye" class="w-4 h-4"></i>
                                        Live Preview
                                    </h4>
                                    <span class="text-xs text-base-content/60">This is how it will look in Odoo</span>
                                </div>
                                <div class="bg-white rounded-box shadow-lg p-6 mx-auto max-w-2xl">
                                    <div id="htmlCardPreview"></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="bg-base-200 p-4 border-t border-base-300 flex gap-2 justify-end">
                            <button class="btn btn-ghost" onclick="closeHtmlCardEditor()">Cancel</button>
                            <button class="btn btn-primary" onclick="saveHtmlCard()">
                                <i data-lucide="save" class="w-4 h-4"></i>
                                Save HTML Card
                            </button>
                        </div>
                    </div>
                    <form method="dialog" class="modal-backdrop">
                        <button>close</button>
                    </form>
                </dialog>
            `;
            
            renderFieldMapping();
            renderWorkflowSteps();
            updateFieldPalette();
            initializeDragAndDrop();
            
            // Restore tab state immediately (before collapse restore)
            const savedState = restoreUIState();
            const tabIndex = savedState?.formStates?.[formId]?.activeTabIndex ?? 0;
            const tabs = document.querySelectorAll('input[name="main_tabs"]');
            if (tabs[tabIndex]) {
                tabs[tabIndex].checked = true;
            }
            
            // Restore collapse state for this specific form
            // First, open ALL collapses by default
            const allCollapseCheckboxes = document.querySelectorAll('.collapse input[type="checkbox"]');
            allCollapseCheckboxes.forEach(checkbox => {
                checkbox.checked = true; // Default: all open
            });
            
            // Then close the ones that were collapsed in saved state
            if (savedState?.formStates?.[formId]?.collapsedSections) {
                savedState.formStates[formId].collapsedSections.forEach(sectionId => {
                    const checkbox = document.getElementById(sectionId);
                    if (checkbox && checkbox.type === 'checkbox') {
                        checkbox.checked = false; // Collapse it
                    }
                });
            }
        }
        
        // Field Mapping with Inline Value Mapping
        function renderFieldMapping() {
            const container = document.getElementById('fieldMapping');
            container.innerHTML = '';
            
            console.log('🎨 [renderFieldMapping] All field mappings:', Object.keys(fieldMapping));
            
            // Group fields by parent (detect composite fields like name_1 with name_1_first_name, name_1_last_name)
            const groupedFields = {};
            const processedFields = new Set();
            
            // Filter out special keys
            const regularFields = Object.keys(fieldMapping).filter(k => !k.startsWith('_'));
            
            console.log('🎨 Regular fields (no _):', regularFields);
            
            regularFields.forEach(formField => {
                // Skip if already processed as a subfield
                if (processedFields.has(formField)) {
                    return;
                }
                
                // Check if this is a composite field subfield by looking for known patterns
                const compositeSubfieldSuffixes = ['_first_name', '_last_name', '_prefix', '_middle_name', '_suffix'];
                let isSubField = false;
                let potentialParent = null;
                
                for (const suffix of compositeSubfieldSuffixes) {
                    if (formField.endsWith(suffix)) {
                        potentialParent = formField.substring(0, formField.length - suffix.length);
                        console.log(`  🔍 Checking ${formField}: ends with ${suffix}, parent would be ${potentialParent}, exists? ${!!fieldMapping[potentialParent]}`);
                        
                        if (fieldMapping[potentialParent] && !potentialParent.startsWith('_')) {
                            // This is a subfield
                            if (!groupedFields[potentialParent]) {
                                groupedFields[potentialParent] = [];
                            }
                            groupedFields[potentialParent].push(formField);
                            processedFields.add(formField);
                            console.log(`  ✅ Added ${formField} as subfield of ${potentialParent}`);
                            isSubField = true;
                            break;
                        }
                    }
                }
                
                // Not a subfield or no parent - treat as regular field
                if (!isSubField && !groupedFields[formField]) {
                    groupedFields[formField] = [];
                }
            });
            
            console.log('🎨 Grouped fields:', groupedFields);
            console.log('🎨 Processed (subfields):', Array.from(processedFields));
            
            // Render fields with subfields grouped - SKIP fields that are subfields themselves
            Object.entries(groupedFields).forEach(([formField, subFields]) => {
                // Skip if this field is itself a subfield
                if (processedFields.has(formField)) {
                    console.log(`  ⏭️ Skipping ${formField} (is a subfield)`);
                    return;
                }
                
                console.log(`  ✏️ Rendering ${formField} with ${subFields.length} subfields`);
                const odooField = fieldMapping[formField];
                const hasSubFields = subFields.length > 0;
                
                const containerDiv = document.createElement('div');
                containerDiv.className = 'collapse collapse-arrow bg-base-200 rounded-box mb-2';
                containerDiv.dataset.field = formField;
                
                const rowDiv = document.createElement('div');
                rowDiv.className = 'flex gap-2 items-center p-4';
                rowDiv.innerHTML = `
                    <input type="text" value="${formField}" data-type="key" class="input input-bordered input-sm flex-1" onchange="updateFieldKey('${formField}', this.value)">
                    <span class="text-base-content/50">→</span>
                    <input type="text" value="${odooField}" data-type="value" class="input input-bordered input-sm flex-1" onchange="updateFieldValue('${formField}', this.value)">
                    ${hasSubFields ? '<span class="badge badge-sm badge-accent">composite</span>' : ''}
                    <button class="btn btn-sm btn-primary" onclick="toggleValueMapping('${formField}')">⚙️</button>
                    <button class="btn btn-sm btn-error btn-square" onclick="deleteField('${formField}')">×</button>
                `;
                
                containerDiv.appendChild(rowDiv);
                
                // Add composite template section if has subfields
                if (hasSubFields) {
                    const compositeDiv = document.createElement('div');
                    compositeDiv.className = 'bg-base-300 p-4 mx-4 mb-4 rounded-box border border-base-content/10';
                    const currentTemplate = fieldMapping['_composite_templates']?.[formField] || subFields.map(sf => '${' + sf.substring(formField.length + 1) + '}').join(' ');
                    compositeDiv.innerHTML = `
                        <label class="label"><span class="label-text text-sm font-semibold">📝 Composite Template</span></label>
                        <input type="text" value="${currentTemplate}" 
                            class="chip-enabled input input-bordered input-sm w-full font-mono text-xs" 
                            placeholder="\${first_name} \${last_name}" 
                            data-field="${formField}"
                            data-template-for="${formField}">
                        <p class="text-xs text-base-content/60 mt-2 flex gap-1 flex-wrap">
                            <span class="opacity-70">Available:</span>
                            ${subFields.map(sf => '<code class="badge badge-xs badge-outline">${' + sf.substring(formField.length + 1) + '}</code>').join(' ')}
                        </p>
                    `;
                    containerDiv.appendChild(compositeDiv);
                    
                    // Show subfields
                    const subFieldsDiv = document.createElement('div');
                    subFieldsDiv.className = 'ml-8 mr-4 space-y-2 mb-4';
                    subFields.forEach(subField => {
                        const subOdooField = fieldMapping[subField];
                        const subRow = document.createElement('div');
                        subRow.className = 'flex gap-2 items-center text-sm p-3 bg-base-200 rounded-lg border border-accent/20';
                        subRow.innerHTML = `
                            <span class="badge badge-xs badge-accent">sub</span>
                            <code class="text-xs flex-1 font-semibold">${subField}</code>
                            <span class="text-base-content/50">→</span>
                            <input type="text" value="${subOdooField}" class="input input-bordered input-xs flex-1" onchange="updateFieldValue('${subField}', this.value)">
                            <button class="btn btn-xs btn-error btn-circle" onclick="deleteField('${subField}')">×</button>
                        `;
                        subFieldsDiv.appendChild(subRow);
                    });
                    containerDiv.appendChild(subFieldsDiv);
                }
                
                // Add inline value mapping section
                const valueMappingDiv = document.createElement('div');
                valueMappingDiv.className = 'bg-base-200 p-4';
                valueMappingDiv.id = `value-mapping-${formField}`;
                
                // Auto-expand if value mappings exist
                const hasValueMappings = valueMapping[formField] && Object.keys(valueMapping[formField]).some(k => !k.startsWith('_'));
                if (hasValueMappings) {
                    expandedValueMappings[formField] = true;
                }
                valueMappingDiv.style.display = expandedValueMappings[formField] ? 'block' : 'none';
                valueMappingDiv.innerHTML = `
                    <div class="divider text-sm">Value Mapping for "${formField}"</div>
                    <div class="form-control mb-3">
                        <label class="label cursor-pointer justify-start gap-2">
                            <input type="checkbox" class="checkbox checkbox-sm" onchange="toggleSkip('${formField}', this.checked)" 
                                ${valueMapping[formField]?._skip ? 'checked' : ''}>
                            <span class="label-text">Skip unmapped values</span>
                        </label>
                        <div class="ml-6 mt-2" id="default-${formField}" style="display:${valueMapping[formField]?._skip ? 'none' : 'block'}">
                            <label class="label"><span class="label-text text-xs">Default value for unmapped:</span></label>
                            <input type="text" value="${valueMapping[formField]?._default || ''}" class="input input-bordered input-sm w-full" 
                                onchange="updateDefaultValue('${formField}', this.value)">
                        </div>
                    </div>
                    <div id="mappings-${formField}" class="space-y-2"></div>
                    <button class="btn btn-sm btn-outline mt-2" onclick="addValueMappingRow('${formField}')">+ Add Value Mapping</button>
                `;
                
                containerDiv.appendChild(valueMappingDiv);
                container.appendChild(containerDiv);
                
                // Always render value mapping rows (even if empty)
                renderValueMappingRows(formField);
            });
            
            // Initialize chips for composite template inputs
            setTimeout(() => {
                document.querySelectorAll('input[data-template-for]').forEach(input => {
                    if (!input._tagify) {
                        const formField = input.dataset.templateFor;
                        new Tagify(input, {
                            mode: 'mix',
                            pattern: /\$\{[^}]+\}/,
                            tagTextProp: 'value',
                            duplicates: true,
                            editTags: false,
                            dropdown: {
                                enabled: 1,
                                position: 'text',
                                mapValueTo: 'value',
                                highlightFirst: true
                            },
                            mixTagsInterpolator: ['${', '}'],
                            callbacks: {
                                change: (e) => {
                                    const value = e.detail.tagify.DOM.input.textContent;
                                    updateCompositeTemplate(formField, value);
                                }
                            }
                        });
                    }
                });
            }, 100);
        }
        
        function renderValueMappingRows(formField) {
            const container = document.getElementById(`mappings-${formField}`);
            if (!container) return;
            
            container.innerHTML = '';
            const mappings = valueMapping[formField] || {};
            
            Object.entries(mappings).forEach(([key, value]) => {
                if (key.startsWith('_')) return; // Skip _skip, _default, _comment
                
                const row = document.createElement('div');
                row.className = 'flex gap-2 items-center';
                row.innerHTML = `
                    <input type="text" value="${key}" data-old-key="${key}" class="input input-bordered input-sm flex-1"
                        onchange="updateValueMappingKey('${formField}', this.dataset.oldKey, this.value)">
                    <span class="text-base-content/50">→</span>
                    <input type="text" value="${value}" class="input input-bordered input-sm flex-1"
                        onchange="updateValueMappingValue('${formField}', '${key}', this.value)">
                    <button class="btn btn-sm btn-error btn-circle" onclick="deleteValueMappingRow('${formField}', '${key}')">×</button>
                `;
                container.appendChild(row);
            });
        }
        
        function toggleValueMapping(formField) {
            expandedValueMappings[formField] = !expandedValueMappings[formField];
            const element = document.getElementById(`value-mapping-${formField}`);
            element.style.display = expandedValueMappings[formField] ? 'block' : 'none';
        }
        
        function toggleSkip(formField, checked) {
            if (!valueMapping[formField]) valueMapping[formField] = {};
            
            if (checked) {
                valueMapping[formField]._skip = true;
                delete valueMapping[formField]._default;
                document.getElementById(`default-${formField}`).style.display = 'none';
            } else {
                delete valueMapping[formField]._skip;
                document.getElementById(`default-${formField}`).style.display = 'block';
            }
        }
        
        function updateDefaultValue(formField, value) {
            if (!valueMapping[formField]) valueMapping[formField] = {};
            if (value.trim()) {
                valueMapping[formField]._default = value;
            } else {
                delete valueMapping[formField]._default;
            }
        }
        
        function addValueMappingRow(formField) {
            if (!valueMapping[formField]) valueMapping[formField] = {};
            // Add empty row for inline editing (like domain conditions)
            valueMapping[formField][''] = '';
            renderValueMappingRows(formField);
        }
        
        function updateCompositeTemplate(formField, template) {
            if (!fieldMapping._composite_templates) {
                fieldMapping._composite_templates = {};
            }
            fieldMapping._composite_templates[formField] = template;
            debouncedAutoSave();
        }
        
        function updateValueMappingKey(formField, oldKey, newKey) {
            if (oldKey === newKey) return;
            const value = valueMapping[formField][oldKey];
            delete valueMapping[formField][oldKey];
            valueMapping[formField][newKey] = value;
            event.target.dataset.oldKey = newKey;
            debouncedAutoSave();
        }
        
        function updateValueMappingValue(formField, key, value) {
            valueMapping[formField][key] = value;
            debouncedAutoSave();
        }
        
        function deleteValueMappingRow(formField, key) {
            delete valueMapping[formField][key];
            renderValueMappingRows(formField);
            debouncedAutoSave();
        }
        
        function updateFieldKey(oldKey, newKey) {
            if (oldKey === newKey) return;
            fieldMapping[newKey] = fieldMapping[oldKey];
            delete fieldMapping[oldKey];
            if (valueMapping[oldKey]) {
                valueMapping[newKey] = valueMapping[oldKey];
                delete valueMapping[oldKey];
            }
            renderFieldMapping();
            updateFieldPalette();
        }
        
        function updateFieldValue(key, value) {
            fieldMapping[key] = value;
            updateFieldPalette();
        }
        
        function deleteField(key) {
            delete fieldMapping[key];
            delete valueMapping[key];
            renderFieldMapping();
            updateFieldPalette();
        }
        
        function addFieldRow() {
            // Add empty row directly - user can fill it in
            const tempKey = `field_${Date.now()}`;
            fieldMapping[tempKey] = '';
            renderFieldMapping();
            updateFieldPalette();
            
            // Focus on the first input of the new row
            setTimeout(() => {
                const container = document.getElementById('fieldMapping');
                const lastRow = container.lastElementChild;
                if (lastRow) {
                    const firstInput = lastRow.querySelector('input[data-type="key"]');
                    if (firstInput) {
                        firstInput.select();
                    }
                }
            }, 0);
        }
        
        // Field Palette for Drag & Drop
        function updateFieldPalette(currentStepIdx = null) {
            const palette = document.getElementById('fieldPaletteContent');
            palette.innerHTML = '';
            
            // Form fields section
            const formFieldsSection = document.createElement('div');
            const formFieldsHeader = document.createElement('div');
            formFieldsHeader.className = 'text-xs font-semibold mb-2 text-base-content/60 uppercase';
            formFieldsHeader.textContent = 'Form Fields';
            formFieldsSection.appendChild(formFieldsHeader);
            
            const formFieldsContainer = document.createElement('div');
            formFieldsContainer.className = 'flex flex-wrap gap-2';
            
            // Collect all fields including expanded ones
            const allFields = new Set();
            
            // Add regular mapped fields
            Object.entries(fieldMapping).forEach(([formField, odooField]) => {
                allFields.add({ 
                    odooField, 
                    formField, 
                    isExpanded: false 
                });
            });
            
            // Detect and add expanded composite fields (e.g., name_1 -> first_name, last_name)
            const compositeFieldPattern = /^(.+)_(first_name|last_name|prefix|middle_name|suffix)$/;
            Object.keys(fieldMapping).forEach(formField => {
                // Check if this field has expanded subfields
                const relatedFields = Object.keys(fieldMapping).filter(f => f.startsWith(formField + '_'));
                if (relatedFields.length > 0) {
                    // This is likely a composite field that gets expanded
                    // Add the individual subfields
                    relatedFields.forEach(subField => {
                        const match = subField.match(compositeFieldPattern);
                        if (match) {
                            const subFieldName = match[2]; // e.g., "first_name", "last_name"
                            allFields.add({
                                odooField: subFieldName,
                                formField: subField,
                                isExpanded: true
                            });
                        }
                    });
                }
            });
            
            // Render field chips
            allFields.forEach(({ odooField, formField, isExpanded }) => {
                const chip = document.createElement('div');
                chip.className = `badge badge-sm ${isExpanded ? 'badge-accent' : 'badge-primary'}`;
                chip.textContent = odooField;
                chip.title = isExpanded 
                    ? `Auto-expanded from ${formField.replace(/_first_name|_last_name|_prefix|_middle_name|_suffix$/, '')}` 
                    : `Forminator: ${formField}`;
                chip.draggable = true;
                chip.dataset.field = odooField;
                chip.dataset.formfield = formField;
                chip.dataset.chipType = 'field';
                chip.addEventListener('dragstart', handleDragStart);
                chip.addEventListener('dragend', handleDragEnd);
                formFieldsContainer.appendChild(chip);
            });
            
            formFieldsSection.appendChild(formFieldsContainer);
            palette.appendChild(formFieldsSection);
            
            // Step results section (only show steps before current step)
            const availableSteps = currentStepIdx !== null 
                ? workflowSteps.slice(0, currentStepIdx)
                : workflowSteps;
            
            if (availableSteps.some(s => s.step)) {
                const stepResultsSection = document.createElement('div');
                stepResultsSection.className = 'mt-4';
                
                const stepResultsHeader = document.createElement('div');
                stepResultsHeader.className = 'text-xs font-semibold mb-2 text-base-content/60 uppercase';
                stepResultsHeader.textContent = 'Step Results';
                stepResultsSection.appendChild(stepResultsHeader);
                
                const stepResultsContainer = document.createElement('div');
                stepResultsContainer.className = 'flex flex-wrap gap-2';
                
                availableSteps.forEach((step, idx) => {
                    if (!step.step) return;
                    
                    const fields = step.search?.fields || ['id'];
                    fields.forEach(field => {
                        const chip = document.createElement('div');
                        chip.className = 'badge badge-secondary badge-sm';
                        chip.textContent = `${step.step} ${field}`;
                        chip.title = `Step ${idx + 1}: ${step.model}`;
                        chip.draggable = true;
                        chip.dataset.field = `${step.step}.${field}`;
                        chip.dataset.stepRef = 'true';
                        chip.dataset.chipType = 'step';
                        chip.addEventListener('dragstart', handleDragStart);
                        chip.addEventListener('dragend', handleDragEnd);
                        stepResultsContainer.appendChild(chip);
                    });
                });
                
                stepResultsSection.appendChild(stepResultsContainer);
                palette.appendChild(stepResultsSection);
            }
        }
        
        function handleDragStart(e) {
            if (!e.target.dataset || !e.target.dataset.field) {
                console.warn('Drag started on element without data-field:', e.target);
                return;
            }
            draggedFieldName = e.target.dataset.field;
            e.target.classList.add('opacity-50');
            e.dataTransfer.effectAllowed = 'copy';
        }
        
        function handleDragEnd(e) {
            if (e.target && e.target.classList) {
                e.target.classList.remove('opacity-50');
            }
        }
        
        function initializeDragAndDrop() {
            document.querySelectorAll('.value-row input[type="text"], .value-row textarea').forEach(convertToChipInput);
        }
        
        function convertToChipInput(originalInput) {
            // Skip if already converted
            if (originalInput.hasAttribute('data-chip-converted')) {
                return;
            }
            originalInput.setAttribute('data-chip-converted', 'true');
            
            // Store original value
            const originalValue = originalInput.value || '';
            const placeholder = originalInput.placeholder || '';
            
            // Create wrapper with relative positioning and inherit width
            const wrapper = document.createElement('div');
            wrapper.className = 'relative';
            // Copy width styling from original input
            if (originalInput.style.width) {
                wrapper.style.width = originalInput.style.width;
            }
            if (originalInput.className.includes('flex-1')) {
                wrapper.classList.add('flex-1');
            }
            
            // Create contenteditable div styled as DaisyUI input
            const chipInput = document.createElement('div');
            chipInput.className = 'input input-sm input-bordered flex flex-wrap items-center gap-1 h-auto min-h-[2rem] focus-within:input-accent leading-tight w-full';
            chipInput.contentEditable = 'true';
            
            // Create placeholder span
            const placeholderSpan = document.createElement('span');
            placeholderSpan.className = 'absolute top-2 left-3 pointer-events-none opacity-50 text-sm leading-tight';
            placeholderSpan.textContent = placeholder || 'Typ een waarde of sleep een veld hiernaartoe';
            
            wrapper.appendChild(chipInput);
            wrapper.appendChild(placeholderSpan);
            
            // Create hidden input to store actual value
            const hiddenInput = document.createElement('input');
            hiddenInput.type = 'hidden';
            hiddenInput.name = originalInput.name || '';
            hiddenInput.value = originalValue;
            
            // Copy event handlers
            const changeHandler = originalInput.getAttribute('onchange');
            if (changeHandler) {
                hiddenInput.setAttribute('onchange', changeHandler);
            }
            
            // Replace original input
            originalInput.parentNode.insertBefore(wrapper, originalInput);
            originalInput.parentNode.insertBefore(hiddenInput, originalInput);
            originalInput.remove();
            
            // Store references
            chipInput._hiddenInput = hiddenInput;
            chipInput._placeholder = placeholderSpan;
            
            // Parse and render initial value
            if (originalValue) {
                renderMixedContent(originalValue);
            }
            
            // Update placeholder visibility
            updatePlaceholder();
            
            function updatePlaceholder() {
                const isEmpty = chipInput.textContent.trim() === '' && chipInput.querySelectorAll('[data-field]').length === 0;
                if (placeholderSpan) {
                    placeholderSpan.style.display = isEmpty ? 'block' : 'none';
                }
            }
            
            function renderMixedContent(value) {
                chipInput.innerHTML = '';
                
                // Find all placeholders (both types)
                const fieldPattern = /\$\{(?:field\.)?([a-zA-Z0-9_]+)\}/g;
                const stepPattern = /\$([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]+)/g;
                
                const matches = [];
                let match;
                
                while ((match = fieldPattern.exec(value)) !== null) {
                    matches.push({
                        type: 'field',
                        value: match[1],
                        start: match.index,
                        end: match.index + match[0].length
                    });
                }
                
                fieldPattern.lastIndex = 0;
                while ((match = stepPattern.exec(value)) !== null) {
                    matches.push({
                        type: 'step',
                        value: match[1] + '.' + match[2],
                        start: match.index,
                        end: match.index + match[0].length
                    });
                }
                
                // Sort by position
                matches.sort((a, b) => a.start - b.start);
                
                // Build content with text and chips
                let lastIndex = 0;
                matches.forEach(m => {
                    // Add text before chip
                    if (m.start > lastIndex) {
                        chipInput.appendChild(document.createTextNode(value.substring(lastIndex, m.start)));
                    }
                    // Add chip
                    chipInput.appendChild(createBadge(m.value, m.type));
                    lastIndex = m.end;
                });
                
                // Add remaining text
                if (lastIndex < value.length) {
                    chipInput.appendChild(document.createTextNode(value.substring(lastIndex)));
                }
            }
            
            function createBadge(fieldName, chipType) {
                const isStep = chipType === 'step';
                const badge = document.createElement('span');
                badge.className = isStep ? 'badge badge-secondary badge-sm gap-1 cursor-move' : 'badge badge-primary badge-sm gap-1 cursor-move';
                badge.contentEditable = 'false';
                badge.draggable = true;
                badge.setAttribute('data-field', fieldName);
                badge.setAttribute('data-chip-type', chipType);
                badge.textContent = fieldName;
                
                const removeBtn = document.createElement('button');
                removeBtn.type = 'button';
                removeBtn.className = 'btn btn-ghost btn-xs btn-circle p-0';
                removeBtn.textContent = '×';
                removeBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    badge.remove();
                    updatePlaceholder();
                    serializeValue();
                };
                
                badge.appendChild(removeBtn);
                
                // Drag event for moving chips
                badge.addEventListener('dragstart', (e) => {
                    e.stopPropagation();
                    badge.classList.add('opacity-50');
                    e.dataTransfer.effectAllowed = 'move';
                    e.dataTransfer.setData('text/plain', fieldName);
                    badge._isMoving = true;
                });
                
                badge.addEventListener('dragend', (e) => {
                    badge.classList.remove('opacity-50');
                    badge._isMoving = false;
                });
                
                return badge;
            }
            
            function serializeValue() {
                let value = '';
                
                const walk = (node) => {
                    if (node.nodeType === Node.TEXT_NODE) {
                        value += node.textContent;
                    } else if (node.nodeType === Node.ELEMENT_NODE) {
                        if (node.hasAttribute('data-field')) {
                            const fieldName = node.getAttribute('data-field');
                            const chipType = node.getAttribute('data-chip-type');
                            // ALWAYS use ${} syntax for consistency
                            if (chipType === 'step') {
                                value += '${' + fieldName + '}';
                            } else {
                                value += '${field.' + fieldName + '}';
                            }
                        } else {
                            // Walk children for other elements
                            Array.from(node.childNodes).forEach(walk);
                        }
                    }
                };
                
                Array.from(chipInput.childNodes).forEach(walk);
                
                hiddenInput.value = value;
                updatePlaceholder();
            }
            
            // Event listeners
            chipInput.addEventListener('input', () => {
                serializeValue();
            });
            
            chipInput.addEventListener('blur', () => {
                serializeValue();
                if (changeHandler) {
                    hiddenInput.dispatchEvent(new Event('change'));
                }
            });
            
            // Drag and drop support
            chipInput.addEventListener('dragover', function(e) {
                e.preventDefault();
                e.stopPropagation();
                chipInput.classList.add('input-accent');
            });
            
            chipInput.addEventListener('dragleave', function(e) {
                if (!chipInput.contains(e.relatedTarget)) {
                    chipInput.classList.remove('input-accent');
                }
            });
            
            chipInput.addEventListener('drop', function(e) {
                e.preventDefault();
                e.stopPropagation();
                chipInput.classList.remove('input-accent');
                
                // Check if we're moving an existing chip
                const movingChip = Array.from(chipInput.querySelectorAll('[data-field]')).find(c => c._isMoving);
                
                let badge;
                if (movingChip) {
                    // Moving existing chip
                    badge = movingChip;
                } else if (draggedFieldName) {
                    // Adding new chip from palette
                    const chipType = draggedFieldName.includes('.') ? 'step' : 'field';
                    badge = createBadge(draggedFieldName, chipType);
                }
                
                if (badge) {
                    // Get cursor position
                    let range;
                    if (document.caretPositionFromPoint) {
                        const pos = document.caretPositionFromPoint(e.clientX, e.clientY);
                        if (pos) {
                            range = document.createRange();
                            range.setStart(pos.offsetNode, pos.offset);
                        }
                    } else if (document.caretRangeFromPoint) {
                        range = document.caretRangeFromPoint(e.clientX, e.clientY);
                    }
                    
                    if (range && chipInput.contains(range.startContainer)) {
                        // Remove chip from old position if moving
                        if (movingChip && badge.parentNode) {
                            badge.remove();
                        }
                        
                        // Insert at cursor position
                        if (range.startContainer.nodeType === Node.TEXT_NODE) {
                            const textNode = range.startContainer;
                            const offset = range.startOffset;
                            
                            if (offset > 0 && offset < textNode.length) {
                                const afterText = textNode.splitText(offset);
                                textNode.parentNode.insertBefore(badge, afterText);
                                textNode.parentNode.insertBefore(document.createTextNode(' '), afterText);
                            } else if (offset === 0) {
                                textNode.parentNode.insertBefore(badge, textNode);
                                textNode.parentNode.insertBefore(document.createTextNode(' '), textNode);
                            } else {
                                textNode.parentNode.insertBefore(badge, textNode.nextSibling);
                                textNode.parentNode.insertBefore(document.createTextNode(' '), textNode.nextSibling);
                            }
                        } else {
                            range.insertNode(badge);
                            badge.parentNode.insertBefore(document.createTextNode(' '), badge.nextSibling);
                        }
                    } else if (!movingChip) {
                        // Fallback: append at end
                        chipInput.appendChild(badge);
                        chipInput.appendChild(document.createTextNode(' '));
                    }
                    
                    serializeValue();
                    chipInput.focus();
                }
            });
            
            chipInput.addEventListener('dragenter', function(e) {
                e.preventDefault();
            });
        }
        
        function renderChipContent(chipInput, value, placeholder = null) {
            // Get placeholder from parameter or stored reference
            const placeholderElement = placeholder || chipInput._placeholder;
            chipInput.innerHTML = '';
            
            if (!value) {
                if (placeholderElement) placeholderElement.style.display = 'block';
                return;
            }
            
            if (placeholderElement) placeholderElement.style.display = 'none';
            
            // Parse value and create chips and text nodes
            // Match both field.xxx and xxx for form fields, and stepname.field for step references
            const fieldPattern = new RegExp('\\$\\\{(?:field\.)?([a-zA-Z0-9_]+)\\\}', 'g');
            const stepPattern = new RegExp('\\$([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]+)', 'g');
            
            // Combine both patterns to find all placeholders in order
            const allMatches = [];
            
            // Find all field matches
            let match;
            while ((match = fieldPattern.exec(value)) !== null) {
                allMatches.push({
                    type: 'field',
                    index: match.index,
                    length: match[0].length,
                    fieldName: match[1],
                    fullMatch: match[0]
                });
            }
            
            // Find all step reference matches
            stepPattern.lastIndex = 0;
            while ((match = stepPattern.exec(value)) !== null) {
                allMatches.push({
                    type: 'step',
                    index: match.index,
                    length: match[0].length,
                    fieldName: match[1] + '.' + match[2],
                    fullMatch: match[0]
                });
            }
            
            // Sort by position
            allMatches.sort((a, b) => a.index - b.index);
            
            let lastIndex = 0;
            allMatches.forEach(matchInfo => {
                // Add text before chip
                if (matchInfo.index > lastIndex) {
                    const textBefore = value.substring(lastIndex, matchInfo.index);
                    if (textBefore) {
                        chipInput.appendChild(document.createTextNode(textBefore));
                    }
                }
                
                // Add chip
                const chip = createFieldChip(matchInfo.fieldName, matchInfo.type);
                chipInput.appendChild(chip);
                
                lastIndex = matchInfo.index + matchInfo.length;
            });
            
            // Add remaining text
            if (lastIndex < value.length) {
                const textAfter = value.substring(lastIndex);
                if (textAfter) {
                    chipInput.appendChild(document.createTextNode(textAfter));
                }
            }
            
            // Update placeholder visibility after rendering content
            if (placeholderElement) {
                const hasVisibleContent = Array.from(chipInput.childNodes).some(node => {
                    if (node.nodeType === Node.TEXT_NODE) return node.textContent.trim().length > 0;
                    return node.nodeType === Node.ELEMENT_NODE && node.hasAttribute && node.hasAttribute('data-field');
                });
                placeholderElement.style.display = hasVisibleContent ? 'none' : 'block';
            }
        }
        
        function createFieldChip(fieldName, chipType = 'field', isDraggableWithin = true) {
            const chip = document.createElement('span');
            const isStepChip = chipType === 'step' || fieldName.includes('.');
            chip.className = isStepChip ? 'badge badge-secondary badge-sm' : 'badge badge-primary badge-sm';
            chip.contentEditable = 'false';
            chip.setAttribute('data-field', fieldName);
            chip.setAttribute('data-chip-type', isStepChip ? 'step' : 'field');
            chip.setAttribute('spellcheck', 'false');
            
            if (isDraggableWithin) {
                chip.draggable = true;
                chip.addEventListener('dragstart', function(e) {
                    e.stopPropagation();
                    chip.classList.add('dragging');
                    e.dataTransfer.effectAllowed = 'move';
                    e.dataTransfer.setData('text/plain', fieldName);
                    // Store reference to the chip being moved
                    chip._isMoving = true;
                });
                chip.addEventListener('dragend', function(e) {
                    chip.classList.remove('dragging');
                    chip._isMoving = false;
                });
                chip.addEventListener('dragover', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                });
            }
            
            const label = document.createElement('span');
            label.textContent = fieldName;
            chip.appendChild(label);
            
            const remove = document.createElement('button');
            remove.className = 'btn btn-xs btn-ghost btn-circle p-0 ml-1';
            remove.textContent = '×';
            remove.onclick = function(e) {
                e.stopPropagation();
                chip.remove();
                const chipInput = chip.closest('.chip-input');
                if (chipInput) {
                    updateHiddenValue(chipInput, chipInput._hiddenInput);
                    if (chipInput._hiddenInput) {
                        chipInput._hiddenInput.dispatchEvent(new Event('change'));
                    }
                }
            };
            chip.appendChild(remove);
            
            return chip;
        }
        
        function normalizeChipContent(chipInput) {
            // Clean up any text nodes that might have placeholder syntax
            const walker = document.createTreeWalker(
                chipInput,
                NodeFilter.SHOW_TEXT,
                null
            );
            
            const textNodes = [];
            let node;
            while (node = walker.nextNode()) {
                textNodes.push(node);
            }
            
            textNodes.forEach(textNode => {
                const text = textNode.textContent;
                
                // Match both field patterns and step references
                const fieldPattern = new RegExp('\\$\\\{(?:field\.)?([a-zA-Z0-9_]+)\\\}', 'g');
                const stepPattern = new RegExp('\\$([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]+)', 'g');
                
                // Find all matches
                const allMatches = [];
                let match;
                
                while ((match = fieldPattern.exec(text)) !== null) {
                    allMatches.push({
                        type: 'field',
                        index: match.index,
                        length: match[0].length,
                        fieldName: match[1]
                    });
                }
                
                stepPattern.lastIndex = 0;
                while ((match = stepPattern.exec(text)) !== null) {
                    allMatches.push({
                        type: 'step',
                        index: match.index,
                        length: match[0].length,
                        fieldName: match[1] + '.' + match[2]
                    });
                }
                
                if (allMatches.length > 0) {
                    // Sort by position
                    allMatches.sort((a, b) => a.index - b.index);
                    
                    const fragment = document.createDocumentFragment();
                    let lastIndex = 0;
                    
                    allMatches.forEach(matchInfo => {
                        if (matchInfo.index > lastIndex) {
                            fragment.appendChild(
                                document.createTextNode(text.substring(lastIndex, matchInfo.index))
                            );
                        }
                        fragment.appendChild(createFieldChip(matchInfo.fieldName, matchInfo.type));
                        lastIndex = matchInfo.index + matchInfo.length;
                    });
                    
                    if (lastIndex < text.length) {
                        fragment.appendChild(
                            document.createTextNode(text.substring(lastIndex))
                        );
                    }
                    
                    textNode.parentNode.replaceChild(fragment, textNode);
                }
            });
        }
        
        function updateHiddenValue(chipInput, hiddenInput) {
            if (!hiddenInput) return;
            
            // Get placeholder from stored reference
            const placeholder = chipInput._placeholder;
            
            let value = '';
            let hasContent = false;
            chipInput.childNodes.forEach(node => {
                if (node.nodeType === Node.TEXT_NODE) {
                    const text = node.textContent.trim();
                    if (text) hasContent = true;
                    value += node.textContent;
                } else if (node.nodeType === Node.ELEMENT_NODE && node.hasAttribute && node.hasAttribute('data-field')) {
                    // Check if it's a chip by looking for data-field attribute (more reliable than class names)
                    hasContent = true;
                    const fieldName = node.getAttribute('data-field');
                    const chipType = node.getAttribute('data-chip-type');
                    
                    if (chipType === 'step' || fieldName.includes('.')) {
                        // Step reference
                        value += '$' + fieldName;
                    } else {
                        // Form field
                        value += '$' + '{' + 'field.' + fieldName + '}';
                    }
                }
            });
            
            // Trim leading and trailing whitespace
            hiddenInput.value = value.trim();
            
            // Toggle placeholder visibility
            if (placeholder) {
                placeholder.style.display = hasContent ? 'none' : 'block';
            }
        }
        
        function handleChipDrop(e, chipInput, hiddenInput) {
            e.preventDefault();
            e.stopPropagation();
            chipInput.classList.remove('!border-primary', 'bg-primary/10');
            
            // Get placeholder from stored reference
            const placeholder = chipInput._placeholder;
            
            // Check if we're moving an existing chip within this input
            const movingChip = Array.from(chipInput.querySelectorAll('[data-field]')).find(c => c._isMoving);
            
            let chip;
            if (movingChip) {
                // Moving existing chip
                chip = movingChip;
                chip.remove(); // Remove from current position
            } else if (draggedFieldName) {
                // Adding new chip from palette - determine type by checking if it's a step reference
                const chipType = draggedFieldName.includes('.') ? 'step' : 'field';
                chip = createFieldChip(draggedFieldName, chipType);
            } else {
                return;
            }
            
            // Find the drop position using caret position from mouse coordinates
            let dropRange;
            if (document.caretPositionFromPoint) {
                const position = document.caretPositionFromPoint(e.clientX, e.clientY);
                if (position) {
                    dropRange = document.createRange();
                    dropRange.setStart(position.offsetNode, position.offset);
                }
            } else if (document.caretRangeFromPoint) {
                dropRange = document.caretRangeFromPoint(e.clientX, e.clientY);
            }
            
            // Insert the chip at the cursor position
            if (dropRange && dropRange.startContainer) {
                // If we're in a text node, split it at the cursor position
                if (dropRange.startContainer.nodeType === Node.TEXT_NODE) {
                    const textNode = dropRange.startContainer;
                    const offset = dropRange.startOffset;
                    
                    // Split the text node if we're in the middle
                    if (offset > 0 && offset < textNode.length) {
                        const afterText = textNode.splitText(offset);
                        textNode.parentNode.insertBefore(chip, afterText);
                    } else if (offset === 0) {
                        textNode.parentNode.insertBefore(chip, textNode);
                    } else {
                        textNode.parentNode.insertBefore(chip, textNode.nextSibling);
                    }
                } else {
                    // Insert at the specified container and offset
                    const container = dropRange.startContainer === chipInput ? chipInput : dropRange.startContainer.parentNode;
                    if (container === chipInput || chipInput.contains(container)) {
                        if (dropRange.startOffset < container.childNodes.length) {
                            container.insertBefore(chip, container.childNodes[dropRange.startOffset]);
                        } else {
                            container.appendChild(chip);
                        }
                    } else {
                        chipInput.appendChild(chip);
                    }
                }
            } else {
                // Fallback: append at the end
                chipInput.appendChild(chip);
            }
            
            // Ensure there's a text node after the chip for cursor placement
            let textNodeAfter = chip.nextSibling;
            if (!textNodeAfter || textNodeAfter.nodeType !== Node.TEXT_NODE) {
                textNodeAfter = document.createTextNode(' ');
                chipInput.insertBefore(textNodeAfter, chip.nextSibling);
            }
            
            // Hide placeholder immediately when chip is added
            if (placeholder) {
                placeholder.style.display = 'none';
            }
            
            // Force update placeholder visibility
            updateHiddenValue(chipInput, hiddenInput);
            
            // Trigger change event
            hiddenInput.dispatchEvent(new Event('change'));
            
            // Set cursor after the chip with a small delay to let DOM update
            setTimeout(() => {
                chipInput.focus();
                const selection = window.getSelection();
                const cursorRange = document.createRange();
                try {
                    // Ensure text node still exists and set cursor at the start of it
                    const targetNode = textNodeAfter.nodeType === Node.TEXT_NODE ? textNodeAfter : chipInput;
                    const offset = targetNode === chipInput ? 0 : 0;
                    cursorRange.setStart(targetNode, offset);
                    cursorRange.collapse(true);
                    selection.removeAllRanges();
                    selection.addRange(cursorRange);
                } catch (e) {
                    // Fallback: just focus the input
                    console.warn('Could not set cursor position:', e);
                }
            }, 10);
        }
        
        function makeDropZone(element) {
            element.addEventListener('dragover', handleDragOver);
            element.addEventListener('dragleave', handleDragLeave);
            element.addEventListener('drop', handleDrop);
        }
        
        function makeEmptyDropZone(element, type, stepIdx) {
            element.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'copy';
                element.classList.add('!border-primary', 'bg-primary/10', 'text-primary');
            });
            
            element.addEventListener('dragleave', (e) => {
                if (e.target === element) {
                    element.classList.remove('!border-primary', 'bg-primary/10', 'text-primary');
                }
            });
            
            element.addEventListener('drop', (e) => {
                e.preventDefault();
                element.classList.remove('!border-primary', 'bg-primary/10', 'text-primary');
                
                if (!draggedFieldName) {
                    return;
                }
                
                if (type === 'domain') {
                    if (!workflowSteps[stepIdx].search._customDomain) workflowSteps[stepIdx].search._customDomain = [];
                    workflowSteps[stepIdx].search._customDomain.push([draggedFieldName, '=', '', 'text']);
                    renderDomain(stepIdx, workflowSteps[stepIdx].search._customDomain);
                } else if (type === 'fields') {
                    if (!workflowSteps[stepIdx].search.fields) workflowSteps[stepIdx].search.fields = [];
                    workflowSteps[stepIdx].search.fields.push(draggedFieldName);
                    renderSearchFields(stepIdx, workflowSteps[stepIdx].search.fields);
                } else if (type === 'create') {
                    if (!workflowSteps[stepIdx].create) workflowSteps[stepIdx].create = {};
                    workflowSteps[stepIdx].create[draggedFieldName] = '$' + '{field.' + draggedFieldName + '}';
                    renderCreateValues(stepIdx, workflowSteps[stepIdx].create);
                } else if (type === 'update') {
                    if (!workflowSteps[stepIdx].update.fields) workflowSteps[stepIdx].update.fields = {};
                    workflowSteps[stepIdx].update.fields[draggedFieldName] = '$' + '{field.' + draggedFieldName + '}';
                    console.log('Added field to update:', draggedFieldName, 'Step:', stepIdx, 'Update object:', workflowSteps[stepIdx].update);
                    renderUpdateValues(stepIdx, workflowSteps[stepIdx].update);
                }
            });
        }
        
        function handleDragOver(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
            if (!e.target.classList.contains('border-primary')) {
                e.target.classList.add('!border-primary', 'bg-primary/10');
            }
        }
        
        function handleDragLeave(e) {
            // Only remove if we're actually leaving the element
            if (e.target === e.currentTarget) {
                e.target.classList.remove('!border-primary', 'bg-primary/10');
            }
        }
        
        function handleDrop(e) {
            e.preventDefault();
            e.target.classList.remove('!border-primary', 'bg-primary/10');
            
            // This is for non-chip inputs only (chip inputs use handleChipDrop)
            if (draggedFieldName && e.target.tagName === 'INPUT') {
                const placeholder = '$' + '{field.' + draggedFieldName + '}';
                const input = e.target;
                const cursorPos = input.selectionStart || input.value.length;
                const newValue = input.value.substring(0, cursorPos) + placeholder + input.value.substring(cursorPos);
                input.value = newValue;
                input.dispatchEvent(new Event('input'));
                input.dispatchEvent(new Event('change'));
            }
        }
        
        // Workflow Steps
        // Load missing search fields to CREATE and UPDATE (only adds fields that don't exist)
        function loadFieldsFromSearch(stepIdx) {
            const step = workflowSteps[stepIdx];
            const searchFields = step.search?.fields || [];
            
            if (searchFields.length === 0) {
                showAlert('No search fields to load', 'warning');
                return;
            }
            
            // Initialize CREATE if doesn't exist
            if (!step.create) step.create = {};
            
            // Initialize UPDATE if doesn't exist
            if (!step.update) step.update = {};
            if (!step.update.fields) step.update.fields = {};
            
            let addedToCreate = 0;
            let addedToUpdate = 0;
            
            // Add only missing search fields to CREATE with empty values
            searchFields.forEach(field => {
                if (!step.create.hasOwnProperty(field)) {
                    step.create[field] = '';
                    addedToCreate++;
                }
                if (!step.update.fields.hasOwnProperty(field)) {
                    step.update.fields[field] = '';
                    addedToUpdate++;
                }
            });
            
            // Re-render sections
            renderCreateValues(stepIdx, step.create);
            renderUpdateValues(stepIdx, step.update);
            
            // Show feedback
            const message = `Added ${addedToCreate} field(s) to CREATE and ${addedToUpdate} field(s) to UPDATE`;
            showAlert(addedToCreate > 0 || addedToUpdate > 0 ? message : 'All fields already present', 'info');
            
            // Save changes
            debouncedAutoSave();
        }
        
        function renderWorkflowSteps() {
            const container = document.getElementById('workflowSteps');
            
            // Preserve scroll position and focused element
            const scrollParent = container.closest('.overflow-y-auto') || container.parentElement;
            const previousScrollTop = scrollParent?.scrollTop || 0;
            const focusedElement = document.activeElement;
            const focusedElementPath = getFocusPath(focusedElement);
            
            // Preserve ALL collapse states if not explicitly set
            if (preservedCollapseStates === null) {
                preservedCollapseStates = [];
                workflowSteps.forEach((step, i) => {
                    const checkbox = document.getElementById(`step-toggle-${i}`);
                    if (checkbox) {
                        preservedCollapseStates.push(checkbox.checked);
                    } else {
                        preservedCollapseStates.push(true); // Default: open
                    }
                });
            }
            
            container.innerHTML = '';
            
            workflowSteps.forEach((step, idx) => {
                const stepEl = document.createElement('div');
                stepEl.className = 'workflow-step collapsed';
                stepEl.dataset.index = idx;
                
                const resultBadge = step.step ? `<div class="badge badge-accent">$${step.step}</div>` : '';
                const isNewStep = step.step === 'new_step';
                const shouldBeChecked = preservedCollapseStates !== null ? (preservedCollapseStates[idx] ?? !isNewStep) : !isNewStep;
                
                stepEl.innerHTML = `
                    <div class="collapse collapse-arrow bg-base-100 shadow-md rounded-box mb-4">
                        <input type="checkbox" id="step-toggle-${idx}" ${shouldBeChecked ? 'checked' : ''} /> 
                        <div class="collapse-title relative">
                            <div class="flex items-center gap-2">
                                <i data-lucide="layers" class="w-5 h-5"></i>
                                <span class="text-lg font-semibold">Step: ${step.step || '(unnamed)'} - Model: ${step.model || '(no model)'}</span>
                                ${resultBadge}
                            </div>
                            <button class="btn btn-sm btn-error btn-outline absolute top-4 right-14 z-10" onclick="deleteStep(${idx}); event.stopPropagation();">
                                <i data-lucide="trash-2" class="w-4 h-4"></i>
                            </button>
                        </div>
                        <div class="collapse-content">
                            <div class="space-y-4">
                                <div class="grid grid-cols-2 gap-4">
                                    <div class="form-control">
                                        <label class="label py-1"><span class="label-text font-medium">Step Name:</span></label>
                                        <input type="text" class="input input-bordered" value="${step.step || ''}" onchange="updateStepBasic(${idx}, 'step', this.value)">
                                    </div>
                                    <div class="form-control">
                                        <label class="label py-1"><span class="label-text font-medium">Odoo Model:</span></label>
                                        <select class="select select-bordered" onchange="updateStepModel(${idx}, this.value)">
                                            <option value="">Selecteer model...</option>
                                            ${Object.entries(ODOO_MODELS).map(([key, config]) => `
                                                <option value="${key}" ${step.model === key ? 'selected' : ''}>${config.name}</option>
                                            `).join('')}
                                        </select>
                                        ${step.model && !ODOO_MODELS[step.model] ? `<input type="text" class="input input-bordered mt-2" value="${step.model}" onchange="updateStepBasic(${idx}, 'model', this.value)" placeholder="Custom model naam">` : ''}
                                    </div>
                                </div>
                        
                        <!-- Step Tabs -->
                        <div role="tablist" class="tabs tabs-boxed bg-base-200 mb-4">
                            <a role="tab" class="tab tab-active" onclick="switchStepTab(${idx}, 0)">🔍 Search</a>
                            <a role="tab" class="tab" onclick="switchStepTab(${idx}, 1)">➕ Create</a>
                            <a role="tab" class="tab" onclick="switchStepTab(${idx}, 2)">✏️ Update</a>
                            <a role="tab" class="tab" onclick="switchStepTab(${idx}, 3)">🎨 HTML Card</a>
                        </div>
                        
                        <!-- Tab Panels -->
                        <div class="step-tab-panels">
                            <!-- Search Panel -->
                            <div class="step-tab-panel active" data-step="${idx}" data-panel="0">
                                ${renderSearchTemplate(idx, step)}
                            </div>
                            
                            <!-- Create Panel -->
                            <div class="step-tab-panel hidden" data-step="${idx}" data-panel="1">
                                <div class="flex gap-2 mb-3">
                                    <button class="btn btn-outline flex-1" onclick="addCreateValue(${idx})">
                                        <i data-lucide="plus" class="w-4 h-4"></i>
                                        Add Value
                                    </button>
                                    <button class="btn btn-info" onclick="loadFieldsFromSearch(${idx})" title="Load missing fields from Search section">
                                        <i data-lucide="download" class="w-4 h-4"></i>
                                        Load from Search
                                    </button>
                                </div>
                                <div id="create-${idx}" class="space-y-2 mb-3"></div>
                                
                                <!-- Chatter Message -->
                                <div class="bg-base-300 rounded-lg p-3 mt-4">
                                    <div class="flex items-center gap-2 mb-2">
                                        <i data-lucide="message-circle" class="w-4 h-4"></i>
                                        <span class="font-semibold text-sm">Chatter Message</span>
                                    </div>
                                    <input type="text" 
                                        value="${step._chatter?.create || ''}" 
                                        placeholder="Optional message to post in chatter" 
                                        class="input input-sm input-bordered w-full chip-enabled" 
                                        onchange="updateChatterMessage(${idx}, 'create', this.value)">
                                </div>
                                
                                <div class="collapse collapse-arrow rounded-box ${(step.create && Object.keys(step.create).length > 0) ? 'bg-success' : 'bg-warning'} ${(step.create && Object.keys(step.create).length > 0) ? 'text-success-content' : 'text-warning-content'}">
                                    <input type="checkbox" checked /> 
                                    <div class="collapse-title">
                                        <div class="flex items-center gap-2 text-sm">
                                            <i data-lucide="file-json" class="w-4 h-4"></i>
                                            <span>Create payload preview (${Object.keys(step.create || {}).length} fields)</span>
                                        </div>
                                    </div>
                                    <div class="collapse-content">
                                        <pre class="text-xs overflow-x-auto whitespace-pre-wrap break-all bg-base-100/20 p-2 rounded-box">${JSON.stringify(step.create || {}, null, 2)}</pre>
                                        ${(step.create && Object.keys(step.create).length > 0) ? '<div class="text-sm mt-2 flex items-center gap-1"><i data-lucide="check-circle" class="w-4 h-4"></i> Klaar om op te slaan</div>' : '<div class="text-sm mt-2 flex items-center gap-1"><i data-lucide="alert-triangle" class="w-4 h-4"></i> Voeg velden toe hierboven</div>'}
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Update Panel -->
                            <div class="step-tab-panel hidden" data-step="${idx}" data-panel="2">
                                <div class="flex gap-2 mb-3">
                                    <button class="btn btn-outline flex-1" onclick="addUpdateValue(${idx})">
                                        <i data-lucide="plus" class="w-4 h-4"></i>
                                        Add Field
                                    </button>
                                    <button class="btn btn-info" onclick="loadFieldsFromSearch(${idx})" title="Load missing fields from Search section">
                                        <i data-lucide="download" class="w-4 h-4"></i>
                                        Load from Search
                                    </button>
                                </div>
                                <div id="update-${idx}" class="space-y-2 mb-3"></div>
                                
                                <!-- Chatter Message -->
                                <div class="bg-base-300 rounded-lg p-3 mt-4">
                                    <div class="flex items-center gap-2 mb-2">
                                        <i data-lucide="message-circle" class="w-4 h-4"></i>
                                        <span class="font-semibold text-sm">Chatter Message</span>
                                    </div>
                                    <input type="text" 
                                        value="${step._chatter?.update || ''}" 
                                        placeholder="Optional message to post in chatter" 
                                        class="input input-sm input-bordered w-full chip-enabled" 
                                        onchange="updateChatterMessage(${idx}, 'update', this.value)">
                                </div>
                                
                                <div class="collapse collapse-arrow rounded-box ${(step.update?.fields && Object.keys(step.update.fields).length > 0) ? 'bg-success' : 'bg-warning'} ${(step.update?.fields && Object.keys(step.update.fields).length > 0) ? 'text-success-content' : 'text-warning-content'}">
                                    <input type="checkbox" checked /> 
                                    <div class="collapse-title">
                                        <div class="flex items-center gap-2 text-sm">
                                            <i data-lucide="file-json" class="w-4 h-4"></i>
                                            <span>Update payload preview (${Object.keys(step.update?.fields || {}).length} fields)</span>
                                        </div>
                                    </div>
                                    <div class="collapse-content">
                                        <pre class="text-xs overflow-x-auto whitespace-pre-wrap break-all bg-base-100/20 p-2 rounded-box">${JSON.stringify(step.update || {}, null, 2)}</pre>
                                        ${(step.update?.fields && Object.keys(step.update.fields).length > 0) ? '<div class="text-sm mt-2 flex items-center gap-1"><i data-lucide="check-circle" class="w-4 h-4"></i> Klaar om op te slaan</div>' : '<div class="text-sm mt-2 flex items-center gap-1"><i data-lucide="alert-triangle" class="w-4 h-4"></i> Voeg velden toe hierboven</div>'}
                                    </div>
                                </div>
                            </div>
                            
                            <!-- HTML Card Panel -->
                            <div class="step-tab-panel hidden" data-step="${idx}" data-panel="3">
                                <p class="text-sm text-base-content/70 mb-3">
                                    Build a custom HTML card/form with drag & drop field placeholders
                                </p>
                                <button class="btn btn-primary" onclick="openHtmlCardEditor(${idx})">
                                    <i data-lucide="${step.html_card ? 'edit' : 'plus'}" class="w-4 h-4"></i>
                                    ${step.html_card ? 'Edit HTML Card' : 'Create HTML Card'}
                                </button>
                                ${step.html_card ? '<div class="alert alert-success mt-3"><i data-lucide="check-circle" class="w-4 h-4"></i><div><strong>HTML Card configured</strong><br/>' + (function(){try{const d=JSON.parse(step.html_card);return d.sections ? d.sections.length + ' sections' : (d.selectedFields ? d.selectedFields.length + ' fields' : 'configured');}catch(e){return 'configured';}}()) + '</div></div>' : ''}
                            </div>
                        </div>
                    </div>
                </div>
                `;
                container.appendChild(stepEl);
            });
            
            // Render sub-components after DOM is updated
            setTimeout(() => {
                workflowSteps.forEach((step, idx) => {
                    renderDomain(idx, step.search?._customDomain || []);
                    renderSearchFields(idx, step.search?.fields || []);
                    renderCreateValues(idx, step.create || {});
                    renderUpdateValues(idx, step.update || {});
                    renderStepResultChips(idx, step);
                });
                
                // Initialize Lucide icons
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            }, 0);
            
            // Re-initialize drag and drop for newly rendered elements
            initializeDragAndDrop();
            preservedCollapseStates = null; // Clear after rendering
            
            // Restore scroll position and focus
            if (scrollParent && previousScrollTop > 0) {
                scrollParent.scrollTop = previousScrollTop;
            }
            
            restoreFocus(focusedElementPath);
        }
        
        function deleteStep(idx) {
            if (confirm('Delete this workflow step?')) {
                // Save current collapse states before deleting
                const collapseStates = [];
                workflowSteps.forEach((step, i) => {
                    const checkbox = document.getElementById(`step-toggle-${i}`);
                    if (checkbox) {
                        collapseStates.push(checkbox.checked);
                    }
                });
                
                workflowSteps.splice(idx, 1);
                
                // Set preserved states (shifted by one after deletion)
                preservedCollapseStates = [];
                workflowSteps.forEach((step, i) => {
                    const originalIdx = i < idx ? i : i + 1;
                    preservedCollapseStates.push(collapseStates[originalIdx] ?? true);
                });
                
                renderWorkflowSteps();
            }
        }
        
        function updateStepBasic(idx, field, value) {
            workflowSteps[idx][field] = value;
            const stepEl = document.querySelector(`.workflow-step[data-index="${idx}"]`);
            const header = stepEl?.querySelector('h3');
            if (header) {
                header.textContent = `Step: ${workflowSteps[idx].step || '(unnamed)'} - Model: ${workflowSteps[idx].model || '(no model)'}`;
            }
            
            // Update the result badge if step name changed
            if (field === 'step') {
                const badge = stepEl?.querySelector('.badge-accent');
                if (badge) {
                    badge.textContent = value ? `$${value}` : '';
                    badge.style.display = value ? '' : 'none';
                }
                renderStepResultChips(idx, workflowSteps[idx]);
                updateFieldPalette();
            }
        }
        
        function updateStepModel(idx, modelValue) {
            // Store current accordion states before re-rendering
            const accordionStates = {};
            const mainCheckbox = document.getElementById(`step-toggle-${idx}`);
            accordionStates.main = mainCheckbox ? mainCheckbox.checked : false;
            accordionStates.search = document.getElementById(`step-${idx}-search`)?.checked || false;
            accordionStates.create = document.getElementById(`step-${idx}-create`)?.checked || false;
            accordionStates.update = document.getElementById(`step-${idx}-update`)?.checked || false;
            accordionStates.htmlCard = document.getElementById(`step-${idx}-htmlcard`)?.checked || false;
            
            workflowSteps[idx].model = modelValue;
            
            // If model has templates, initialize with template
            if (modelValue && ODOO_MODELS[modelValue] && ODOO_MODELS[modelValue].searchTemplates) {
                const templates = ODOO_MODELS[modelValue].searchTemplates;
                const firstTemplate = Object.values(templates)[0];
                
                if (firstTemplate) {
                    // Initialize search with template defaults
                    workflowSteps[idx].search = workflowSteps[idx].search || {};
                    // Only set default fields if no fields exist yet
                    if (!workflowSteps[idx].search.fields || workflowSteps[idx].search.fields.length === 0) {
                        workflowSteps[idx].search.fields = [...(firstTemplate.defaultFields || [])];
                    }
                    workflowSteps[idx]._templateConfig = {
                        template: Object.keys(templates)[0],
                        values: {},
                        typeFilter: firstTemplate.typeFilter ? 'contact' : null
                    };
                }
            }
            
            renderWorkflowSteps();
            
            // Restore accordion states after re-rendering
            setTimeout(() => {
                const mainCheckboxAfter = document.getElementById(`step-toggle-${idx}`);
                if (mainCheckboxAfter && accordionStates.main) mainCheckboxAfter.checked = true;
                
                const searchCheckbox = document.getElementById(`step-${idx}-search`);
                if (searchCheckbox && accordionStates.search) searchCheckbox.checked = true;
                
                const createCheckbox = document.getElementById(`step-${idx}-create`);
                if (createCheckbox && accordionStates.create) createCheckbox.checked = true;
                
                const updateCheckbox = document.getElementById(`step-${idx}-update`);
                if (updateCheckbox && accordionStates.update) updateCheckbox.checked = true;
                
                const htmlCardCheckbox = document.getElementById(`step-${idx}-htmlcard`);
                if (htmlCardCheckbox && accordionStates.htmlCard) htmlCardCheckbox.checked = true;
            }, 100);
        }
        
        function renderStepResultChips(idx, step) {
            const container = document.getElementById(`result-chips-${idx}`);
            if (!container) return;
            
            container.innerHTML = '';
            
            if (!step.step) {
                container.innerHTML = '<em style="color: #999;">Name the step first to enable result references</em>';
                return;
            }
            
            const fields = step.search?.fields || ['id'];
            fields.forEach(field => {
                const chipItem = document.createElement('div');
                chipItem.className = 'step-result-chip-item';
                chipItem.innerHTML = `
                    <span>$${step.step}.${field}</span>
                    <code>$${step.step}.${field}</code>
                `;
                container.appendChild(chipItem);
            });
        }
        
        function addWorkflowStep() {
            // Save current collapse states before adding
            preservedCollapseStates = [];
            workflowSteps.forEach((step, i) => {
                const checkbox = document.getElementById(`step-toggle-${i}`);
                if (checkbox) {
                    preservedCollapseStates.push(checkbox.checked);
                }
            });
            
            workflowSteps.push({
                step: 'new_step',
                model: '',
                search: { domain: [], fields: [] },
                create: {},
                update: {}
            });
            
            // New step should be collapsed
            preservedCollapseStates.push(false);
            
            renderWorkflowSteps();
        }
        
        // Render search template or fallback to manual mode
        function renderSearchTemplate(idx, step) {
            const model = step.model;
            const modelConfig = ODOO_MODELS[model];
            
            // Fallback to manual mode if no model or custom model
            if (!model || !modelConfig || !modelConfig.searchTemplates || Object.keys(modelConfig.searchTemplates).length === 0) {
                return `
                    <div class="form-control mb-3">
                        <label class="label py-1"><span class="label-text font-medium">Domain Conditions:</span></label>
                        <div id="domain-${idx}" class="space-y-2"></div>
                        <button class="btn btn-sm btn-outline mt-2" onclick="addDomainRow(${idx})">+ Add Condition</button>
                    </div>
                    <div class="form-control">
                        <label class="label py-1"><span class="label-text font-medium">Fields to Retrieve:</span></label>
                        <div id="fields-${idx}" class="flex flex-wrap gap-1 mb-2"></div>
                        <div class="join join-horizontal w-full">
                            <input type="text" id="new-field-${idx}" placeholder="field_name" class="input input-sm input-bordered join-item flex-1">
                            <button class="btn btn-sm btn-outline join-item" onclick="addSearchField(${idx})">+ Add</button>
                        </div>
                    </div>
                `;
            }
            
            // Template mode - show all templates side by side
            const templateConfig = step._templateConfig || {};
            
            let html = `<div class="space-y-4">`;
            
            // Info text - above the columns
            html += `
                <div class="text-xs text-base-content/70">
                    Sleep velden naar de drop zones hieronder. Alleen ingevulde velden worden gebruikt voor zoeken.
                </div>
            `;
            
            html += `<div class="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-4">`;
            
            // LEFT COLUMN - Templates, type filter, custom conditions, preview
            html += `<div class="space-y-3">`;
            
            // Render all templates in a grid
            html += `<div class="grid grid-cols-3 gap-3">`;
            
            Object.entries(modelConfig.searchTemplates).forEach(([templateKey, template]) => {
                const allFields = Object.entries(template.fields);
                const hasValues = allFields.some(([fieldKey]) => templateConfig.values?.[`${templateKey}_${fieldKey}`]);
                
                // Determine icon based on template key
                let icon = 'search';
                if (templateKey === 'email') icon = 'mail';
                else if (templateKey === 'id') icon = 'hash';
                else if (templateKey === 'name') icon = 'user';
                
                html += `
                    <div class="card bg-base-100 shadow rounded-box ${hasValues ? 'ring-2 ring-primary' : ''}">
                        <div class="card-body p-4">
                            <h4 class="card-title text-sm font-medium flex items-center gap-2">
                                <i data-lucide="${icon}" class="w-4 h-4"></i>
                                <span>${template.name}</span>
                            </h4>
                            <div class="space-y-2">
                `;
                
                allFields.forEach(([fieldKey, fieldConfig]) => {
                    const label = typeof fieldConfig === 'string' ? fieldConfig : fieldConfig.label;
                    const dropOnly = typeof fieldConfig === 'object' ? fieldConfig.dropOnly : false;
                    const currentValue = templateConfig.values?.[`${templateKey}_${fieldKey}`] || '';
                    
                    html += `
                        <div class="form-control">
                            <label class="label py-0.5">
                                <span class="label-text text-sm">${label}</span>
                            </label>
                            ${dropOnly ? `
                                <div class="badge badge-outline badge-lg drop-zone w-full cursor-pointer h-10 justify-start px-3 text-sm border-dashed rounded-badge" 
                                     ondragover="handleDragOver(event)"
                                     ondragleave="handleDragLeave(event)"
                                     ondrop="handleTemplateFieldDrop(event, ${idx}, '${templateKey}_${fieldKey}')"
                                     onclick="clearTemplateField(${idx}, '${templateKey}_${fieldKey}')"
                                     title="Sleep een veld hierheen of klik om te wissen">
                                    ${currentValue ? `<span class="font-mono">${currentValue}</span>` : '<span class="text-base-content/40">Sleep veld hier 👆</span>'}
                                </div>
                            ` : `
                                <input 
                                    type="text" 
                                    class="input input-sm input-bordered rounded-lg" 
                                    value="${currentValue}"
                                    placeholder="$contact.id"
                                    onchange="updateTemplateValue(${idx}, '${templateKey}_${fieldKey}', this.value)"
                                >
                            `}
                        </div>
                    `;
                });
                
                html += `
                            </div>
                        </div>
                    </div>
                `;
            });
            
            html += `</div>`; // Close grid
            
            // Type filter (contact/bedrijf) for res.partner
            const hasTypeFilter = Object.values(modelConfig.searchTemplates).some(t => t.typeFilter);
            if (hasTypeFilter) {
                const currentType = templateConfig.typeFilter || 'contact';
                html += `
                    <div class="card bg-base-100 shadow rounded-box">
                        <div class="card-body p-4">
                            <div class="card-title text-sm font-medium flex items-center gap-2">
                                <i data-lucide="filter" class="w-4 h-4"></i>
                                <span>Type filter</span>
                            </div>
                            <div class="btn-group w-full">
                                <input type="radio" name="type-${idx}" value="both" class="btn btn-sm flex-1" aria-label="Beide" ${currentType === 'both' ? 'checked' : ''} onchange="updateTemplateTypeFilter(${idx}, this.value)">
                                <input type="radio" name="type-${idx}" value="contact" class="btn btn-sm flex-1" aria-label="Contacten" ${currentType === 'contact' ? 'checked' : ''} onchange="updateTemplateTypeFilter(${idx}, this.value)">
                                <input type="radio" name="type-${idx}" value="company" class="btn btn-sm flex-1" aria-label="Bedrijven" ${currentType === 'company' ? 'checked' : ''} onchange="updateTemplateTypeFilter(${idx}, this.value)">
                            </div>
                        </div>
                    </div>
                `;
            }
            
            // Custom conditions section
            html += `
                <div class="collapse collapse-arrow bg-base-100 shadow rounded-box">
                    <input type="checkbox" id="custom-conditions-${idx}" checked />
                    <div class="collapse-title">
                        <div class="flex items-center gap-2 text-sm font-medium">
                            <i data-lucide="settings" class="w-4 h-4"></i>
                            <span>Aangepaste condities (optioneel)</span>
                        </div>
                    </div>
                    <div class="collapse-content">
                        <div class="form-control">
                            <label class="label"><span class="label-text">Extra domain condities:</span></label>
                            <div id="domain-${idx}" class="space-y-2"></div>
                            <button class="btn btn-outline mt-2" onclick="addDomainRow(${idx})">+ Add Condition</button>
                        </div>
                    </div>
                </div>
            `;
            
            // Show generated domain preview
            const previewDomain = generateDomainFromTemplate(idx, step);
            const hasAnyValues = templateConfig.values && Object.values(templateConfig.values).some(v => v);
            const hasCustomConditions = step.search?._customDomain && step.search._customDomain.length > 0;
            const isSuccess = hasAnyValues || hasCustomConditions;
            
            html += `
                <div class="collapse collapse-arrow shadow rounded-box ${isSuccess ? 'bg-success' : 'bg-warning'} ${isSuccess ? 'text-success-content' : 'text-warning-content'}">
                    <input type="checkbox" id="generated-domain-${idx}" checked />
                    <div class="collapse-title">
                        <div class="flex items-center gap-2 text-sm font-medium">
                            <i data-lucide="code" class="w-4 h-4"></i>
                            <span>Generated domain (${previewDomain.length} conditions)</span>
                        </div>
                    </div>
                    <div class="collapse-content">
                        <pre class="text-xs overflow-x-auto whitespace-pre-wrap break-all bg-base-100/20 p-2 rounded-box">${JSON.stringify(previewDomain, null, 2)}</pre>
                        ${isSuccess ? '<div class="text-xs mt-1">✓ Klaar om op te slaan</div>' : '<div class="text-xs mt-1">⚠ Sleep velden naar de drop zones hierboven</div>'}
                    </div>
                </div>
            `;
            
            html += `</div>`; // Close left column
            
            // RIGHT COLUMN - Fields to retrieve
            html += `<div class="flex flex-col">`;
            
            html += `
                <div class="card bg-base-100 shadow rounded-box h-full">
                    <div class="card-body p-4">
                        <div class="card-title text-sm font-medium flex items-center gap-2">
                            <i data-lucide="database" class="w-4 h-4"></i>
                            <span>Op te halen velden</span>
                        </div>
                        <div class="text-sm text-base-content/70">Velden die worden opgehaald na zoeken in Odoo (${step.search?.fields?.length || 0})</div>
                        <div class="join w-full">
                            <input id="new-field-${idx}" type="text" placeholder="Voeg veld toe..." class="input input-sm input-bordered join-item flex-1" onkeydown="if(event.key === 'Enter') addSearchField(${idx})">
                            <button class="btn btn-sm btn-primary join-item" onclick="addSearchField(${idx})">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" /></svg>
                            </button>
                        </div>
                        <div id="fields-${idx}" class="flex flex-wrap gap-1.5 min-h-[2rem] p-2 bg-base-200 rounded-box content-start flex-1 overflow-y-auto"></div>
                    </div>
                </div>
            `;
            
            html += `</div>`; // Close right column
            html += `</div>`; // Close grid
            html += `</div>`; // Close wrapper
            return html;
        }
        
        function generateDomainFromTemplate(idx, step) {
            const model = step.model;
            const modelConfig = ODOO_MODELS[model];
            if (!modelConfig || !modelConfig.searchTemplates) return step.search?._customDomain || [];
            
            const templateConfig = step._templateConfig || {};
            let combinedDomain = [];
            
            // Combine all templates that have values
            Object.entries(modelConfig.searchTemplates).forEach(([templateKey, template]) => {
                if (!template.buildDomain) return;
                
                // Extract values for this specific template
                const templateValues = {};
                Object.entries(templateConfig.values || {}).forEach(([key, value]) => {
                    if (key.startsWith(templateKey + '_') && value) {
                        const fieldKey = key.substring(templateKey.length + 1);
                        templateValues[fieldKey] = value;
                    }
                });
                
                // Only add domain if this template has values
                if (Object.keys(templateValues).length > 0) {
                    const domain = template.buildDomain(templateValues, templateConfig.typeFilter);
                    combinedDomain = combinedDomain.concat(domain);
                }
            });
            
            // Add custom domain conditions from separate storage (NOT step.search.domain)
            if (step.search?._customDomain && Array.isArray(step.search._customDomain)) {
                combinedDomain = combinedDomain.concat(step.search._customDomain);
            }
            
            return combinedDomain;
        }
        
        function updateSearchTemplate(idx, templateKey) {
            const modelConfig = ODOO_MODELS[workflowSteps[idx].model];
            const template = modelConfig.searchTemplates[templateKey];
            
            workflowSteps[idx]._templateConfig = {
                template: templateKey,
                values: {},
                typeFilter: template.typeFilter ? 'contact' : null
            };
            workflowSteps[idx].search.fields = template.defaultFields || [];
            
            renderWorkflowSteps();
        }
        
        function updateTemplateValue(idx, fieldKey, value) {
            if (!workflowSteps[idx]._templateConfig) {
                workflowSteps[idx]._templateConfig = { values: {} };
            }
            workflowSteps[idx]._templateConfig.values = workflowSteps[idx]._templateConfig.values || {};
            workflowSteps[idx]._templateConfig.values[fieldKey] = value;
            
            // Re-render to update preview (generateDomainFromTemplate will be called during render)
            renderWorkflowSteps();
            
            // Auto-save
            debouncedAutoSave();
        }
        
        function handleTemplateFieldDrop(e, idx, fieldKey) {
            e.preventDefault();
            e.stopPropagation();
            e.target.classList.remove('!border-primary', 'bg-primary/10');
            
            if (draggedFieldName) {
                // Palette chips contain "contact.id", wrap in ${...}
                updateTemplateValue(idx, fieldKey, '${' + draggedFieldName + '}');
            }
        }
        
        function clearTemplateField(idx, fieldKey) {
            if (workflowSteps[idx]._templateConfig?.values?.[fieldKey]) {
                updateTemplateValue(idx, fieldKey, '');
            }
        }
        
        function updateTemplateTypeFilter(idx, type) {
            if (!workflowSteps[idx]._templateConfig) {
                workflowSteps[idx]._templateConfig = {};
            }
            workflowSteps[idx]._templateConfig.typeFilter = type;
            
            // Re-render to update preview
            renderWorkflowSteps();
            
            // Auto-save
            debouncedAutoSave();
        }
        
        // Domain Editor
        function renderDomain(stepIdx, domain) {
            console.log('renderDomain called for step', stepIdx, 'domain:', domain);
            const container = document.getElementById(`domain-${stepIdx}`);
            container.innerHTML = '';
            
            // Ensure we're using _customDomain for custom conditions
            if (!workflowSteps[stepIdx].search._customDomain) {
                workflowSteps[stepIdx].search._customDomain = [];
            }
            
            const customDomain = workflowSteps[stepIdx].search._customDomain;
            
            if (customDomain.length === 0) {
                return;
            }
            
            domain.forEach((condition, condIdx) => {
                const row = document.createElement('div');
                row.className = 'flex gap-2 items-center';
                
                // Support both old format [field, op, val] and new format [field, op, val, type]
                const field = condition[0] || '';
                const op = condition[1] || '=';
                const val = condition[2] !== undefined ? condition[2] : '';
                const fieldType = condition[3] || 'text';
                
                row.innerHTML = `
                    <input type="text" class="input input-sm input-bordered flex-1" value="${field}" placeholder="field" 
                        onchange="updateDomain(${stepIdx}, ${condIdx}, 0, this.value)">
                    <select class="select select-sm select-bordered" onchange="updateDomainType(${stepIdx}, ${condIdx}, this.value)">
                        <option value="text" ${fieldType === 'text' ? 'selected' : ''}>Text</option>
                        <option value="integer" ${fieldType === 'integer' ? 'selected' : ''}>Integer</option>
                        <option value="float" ${fieldType === 'float' ? 'selected' : ''}>Float</option>
                        <option value="boolean" ${fieldType === 'boolean' ? 'selected' : ''}>Boolean</option>
                        <option value="datetime" ${fieldType === 'datetime' ? 'selected' : ''}>DateTime</option>
                    </select>
                    <select class="select select-sm select-bordered" onchange="updateDomain(${stepIdx}, ${condIdx}, 1, this.value)">
                        <option value="=" ${op === '=' ? 'selected' : ''}>equals (=)</option>
                        <option value="!=" ${op === '!=' ? 'selected' : ''}>not equals (!=)</option>
                        <option value=">" ${op === '>' ? 'selected' : ''}>greater (&gt;)</option>
                        <option value="<" ${op === '<' ? 'selected' : ''}>less (&lt;)</option>
                        <option value=">=" ${op === '>=' ? 'selected' : ''}>greater or equal (&gt;=)</option>
                        <option value="<=" ${op === '<=' ? 'selected' : ''}>less or equal (&lt;=)</option>
                        <option value="like" ${op === 'like' ? 'selected' : ''}>like</option>
                        <option value="ilike" ${op === 'ilike' ? 'selected' : ''}>ilike</option>
                        <option value="in" ${op === 'in' ? 'selected' : ''}>in</option>
                        <option value="not in" ${op === 'not in' ? 'selected' : ''}>not in</option>
                    </select>
                    <div id="value-${stepIdx}-${condIdx}" class="flex-1"></div>
                    <button class="btn btn-sm btn-ghost btn-square" onclick="deleteDomain(${stepIdx}, ${condIdx})">×</button>
                `;
                container.appendChild(row);
                
                // Render the value input based on field type
                renderDomainValue(stepIdx, condIdx, val, fieldType);
            });
        }
        
        function renderDomainValue(stepIdx, condIdx, value, fieldType) {
            const container = document.getElementById(`value-${stepIdx}-${condIdx}`);
            if (!container) return;
            
            container.innerHTML = '';
            
            if (fieldType === 'boolean') {
                // Boolean: true/false select
                const select = document.createElement('select');
                select.className = 'select select-sm select-bordered w-full';
                select.onchange = function() {
                    const boolVal = this.value === 'true';
                    updateDomain(stepIdx, condIdx, 2, boolVal);
                };
                
                const trueOpt = document.createElement('option');
                trueOpt.value = 'true';
                trueOpt.textContent = 'True';
                trueOpt.selected = value === true;
                
                const falseOpt = document.createElement('option');
                falseOpt.value = 'false';
                falseOpt.textContent = 'False';
                falseOpt.selected = value === false;
                
                select.appendChild(trueOpt);
                select.appendChild(falseOpt);
                container.appendChild(select);
                
            } else if (fieldType === 'integer') {
                // Integer input
                const input = document.createElement('input');
                input.className = 'input input-sm input-bordered w-full';
                input.type = 'number';
                input.step = '1';
                input.value = value;
                input.placeholder = 'integer value';
                input.onchange = function() {
                    updateDomain(stepIdx, condIdx, 2, parseInt(this.value) || 0);
                };
                container.appendChild(input);
                
            } else if (fieldType === 'float') {
                // Float input
                const input = document.createElement('input');
                input.className = 'input input-sm input-bordered w-full';
                input.type = 'number';
                input.step = 'any';
                input.value = value;
                input.placeholder = 'decimal value';
                input.onchange = function() {
                    updateDomain(stepIdx, condIdx, 2, parseFloat(this.value) || 0);
                };
                container.appendChild(input);
                
            } else if (fieldType === 'datetime') {
                // DateTime input
                const input = document.createElement('input');
                input.className = 'input input-sm input-bordered w-full';
                input.type = 'datetime-local';
                input.value = value;
                input.placeholder = 'YYYY-MM-DD HH:MM';
                input.onchange = function() {
                    updateDomain(stepIdx, condIdx, 2, this.value);
                };
                container.appendChild(input);
                
            } else {
                // Text input with chip support
                const input = document.createElement('input');
                input.className = 'input input-sm input-bordered w-full';
                input.type = 'text';
                input.value = value;
                input.placeholder = 'value';
                input.setAttribute('onchange', 'updateDomain(' + stepIdx + ', ' + condIdx + ', 2, this.value)');
                container.appendChild(input);
                
                // Convert to chip input after a small delay
                setTimeout(() => {
                    convertToChipInput(input);
                }, 0);
            }
        }
        
        function updateDomainType(stepIdx, condIdx, newType) {
            if (!workflowSteps[stepIdx].search._customDomain) {
                workflowSteps[stepIdx].search._customDomain = [];
            }
            // Update the field type
            if (workflowSteps[stepIdx].search._customDomain[condIdx].length === 3) {
                // Convert from old format [field, op, val] to new format [field, op, val, type]
                workflowSteps[stepIdx].search._customDomain[condIdx].push(newType);
            } else {
                workflowSteps[stepIdx].search._customDomain[condIdx][3] = newType;
            }
            
            // Get current value and convert it based on new type
            let currentVal = workflowSteps[stepIdx].search._customDomain[condIdx][2];
            
            if (newType === 'boolean') {
                currentVal = currentVal === 'true' || currentVal === true || currentVal === 1;
            } else if (newType === 'integer') {
                currentVal = parseInt(currentVal) || 0;
            } else if (newType === 'float') {
                currentVal = parseFloat(currentVal) || 0;
            } else {
                currentVal = String(currentVal || '');
            }
            
            workflowSteps[stepIdx].search._customDomain[condIdx][2] = currentVal;
            
            // Re-render the value input
            renderDomainValue(stepIdx, condIdx, currentVal, newType);
            updateDomainPreview(stepIdx);
        }
        
        function addDomainRow(stepIdx) {
            if (!workflowSteps[stepIdx].search) workflowSteps[stepIdx].search = {};
            if (!workflowSteps[stepIdx].search._customDomain) workflowSteps[stepIdx].search._customDomain = [];
            // New format: [field, operator, value, type]
            workflowSteps[stepIdx].search._customDomain.push(['', '=', '', 'text']);
            renderDomain(stepIdx, workflowSteps[stepIdx].search._customDomain);
            updateDomainPreview(stepIdx);
        }
        
        function updateDomain(stepIdx, condIdx, part, value) {
            if (!workflowSteps[stepIdx].search._customDomain) {
                workflowSteps[stepIdx].search._customDomain = [];
            }
            workflowSteps[stepIdx].search._customDomain[condIdx][part] = value;
            updateDomainPreview(stepIdx);
        }
        
        function deleteDomain(stepIdx, condIdx) {
            if (!workflowSteps[stepIdx].search._customDomain) {
                workflowSteps[stepIdx].search._customDomain = [];
            }
            workflowSteps[stepIdx].search._customDomain.splice(condIdx, 1);
            renderDomain(stepIdx, workflowSteps[stepIdx].search._customDomain);
            updateDomainPreview(stepIdx);
        }
        
        function updateDomainPreview(stepIdx) {
            const step = workflowSteps[stepIdx];
            const previewDomain = generateDomainFromTemplate(stepIdx, step);
            const templateConfig = step._templateConfig || {};
            const hasAnyValues = templateConfig.values && Object.values(templateConfig.values).some(v => v);
            const hasCustomConditions = step.search?._customDomain && step.search._customDomain.length > 0;
            const isSuccess = hasAnyValues || hasCustomConditions;
            
            // Update the preview container content
            const previewContainer = document.getElementById(`domain-preview-${stepIdx}`);
            if (previewContainer) {
                previewContainer.innerHTML = `
                    <pre class="text-[10px] overflow-x-auto whitespace-pre-wrap break-all">${JSON.stringify(previewDomain, null, 2)}</pre>
                    ${isSuccess ? '<div class="text-xs mt-1">✓ Klaar om op te slaan</div>' : '<div class="text-xs mt-1">⚠ Sleep velden naar de drop zones hierboven</div>'}
                `;
                
                // Update the collapse background color and text color
                const collapseElement = previewContainer.closest('.collapse');
                if (collapseElement) {
                    // Remove old color classes
                    collapseElement.classList.remove('bg-success', 'bg-warning', 'text-success-content', 'text-warning-content');
                    // Add new color classes
                    if (isSuccess) {
                        collapseElement.classList.add('bg-success', 'text-success-content');
                    } else {
                        collapseElement.classList.add('bg-warning', 'text-warning-content');
                    }
                    
                    // Update the collapse title with condition count
                    const collapseTitle = collapseElement.querySelector('.collapse-title');
                    if (collapseTitle) {
                        collapseTitle.innerHTML = `
                            <i data-lucide="code" class="w-3.5 h-3.5"></i>
                            <span>Generated domain (${previewDomain.length} conditions)</span>
                        `;
                        lucide.createIcons();
                    }
                }
            }
            
            // Auto-save after preview update
            debouncedAutoSave();
        }
        
        // Search Fields
        function renderSearchFields(stepIdx, fields) {
            const container = document.getElementById(`fields-${stepIdx}`);
            if (!container) return; // Container doesn't exist yet
            
            container.innerHTML = '';
            
            if (fields.length === 0) {
                const emptyMsg = document.createElement('div');
                emptyMsg.className = 'text-xs text-base-content/50 italic';
                emptyMsg.textContent = 'Geen velden geselecteerd';
                container.appendChild(emptyMsg);
                return;
            }
            
            fields.forEach((field, fieldIdx) => {
                const tag = document.createElement('div');
                tag.className = 'badge badge-lg badge-neutral gap-2 pr-1';
                tag.innerHTML = `
                    <span>${field}</span>
                    <button class="btn btn-xs btn-ghost btn-circle" onclick="deleteSearchField(${stepIdx}, ${fieldIdx})">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                `;
                container.appendChild(tag);
            });
        }
        
        function addSearchField(stepIdx) {
            const input = document.getElementById(`new-field-${stepIdx}`);
            const value = input.value.trim();
            if (!value) return;
            
            if (!workflowSteps[stepIdx].search) workflowSteps[stepIdx].search = {};
            if (!workflowSteps[stepIdx].search.fields) workflowSteps[stepIdx].search.fields = [];
            workflowSteps[stepIdx].search.fields.push(value);
            input.value = '';
            
            // Sync to CREATE: add field with empty value if not exists
            if (workflowSteps[stepIdx].create && !workflowSteps[stepIdx].create.hasOwnProperty(value)) {
                workflowSteps[stepIdx].create[value] = '';
            }
            
            // Sync to UPDATE: add field with empty value if not exists
            if (workflowSteps[stepIdx].update && workflowSteps[stepIdx].update.fields && !workflowSteps[stepIdx].update.fields.hasOwnProperty(value)) {
                workflowSteps[stepIdx].update.fields[value] = '';
            }
            
            renderSearchFields(stepIdx, workflowSteps[stepIdx].search.fields);
            renderStepResultChips(stepIdx, workflowSteps[stepIdx]);
            renderCreateValues(stepIdx, workflowSteps[stepIdx].create || {});
            renderUpdateValues(stepIdx, workflowSteps[stepIdx].update || {});
            updateFieldPalette();
            debouncedAutoSave();
        }
        
        function deleteSearchField(stepIdx, fieldIdx) {
            const fieldName = workflowSteps[stepIdx].search.fields[fieldIdx];
            workflowSteps[stepIdx].search.fields.splice(fieldIdx, 1);
            
            // Sync to CREATE: remove field
            if (workflowSteps[stepIdx].create && workflowSteps[stepIdx].create.hasOwnProperty(fieldName)) {
                delete workflowSteps[stepIdx].create[fieldName];
                if (workflowSteps[stepIdx]._ui_metadata?.create_types) {
                    delete workflowSteps[stepIdx]._ui_metadata.create_types[fieldName];
                }
            }
            
            // Sync to UPDATE: remove field
            if (workflowSteps[stepIdx].update?.fields?.hasOwnProperty(fieldName)) {
                delete workflowSteps[stepIdx].update.fields[fieldName];
                if (workflowSteps[stepIdx]._ui_metadata?.update_types) {
                    delete workflowSteps[stepIdx]._ui_metadata.update_types[fieldName];
                }
            }
            
            renderSearchFields(stepIdx, workflowSteps[stepIdx].search.fields);
            renderStepResultChips(stepIdx, workflowSteps[stepIdx]);
            renderCreateValues(stepIdx, workflowSteps[stepIdx].create || {});
            renderUpdateValues(stepIdx, workflowSteps[stepIdx].update || {});
            updateFieldPalette();
            debouncedAutoSave();
        }
        
        // Create Values
        // Generate appropriate input HTML based on field type
        function generateValueInput(stepIdx, key, value, fieldType, section = 'create') {
            const displayValue = typeof value === 'object' ? JSON.stringify(value) : String(value);
            const safeKey = key.replace(/\W/g, '_');
            const inputId = `${section}-value-${stepIdx}-${safeKey}`;
            const onchangeHandler = section === 'create' ? 
                `updateCreateValueFromInput(${stepIdx}, '${key}', this)` : 
                `updateUpdateValueFromInput(${stepIdx}, '${key}', this)`;
            
            switch(fieldType) {
                case 'boolean':
                    const boolValue = value === true || value === 'true' || value === 1;
                    return `
                        <div class="flex items-center gap-2 flex-1">
                            <input type="checkbox" id="${inputId}" 
                                class="toggle toggle-sm toggle-success" 
                                ${boolValue ? 'checked' : ''}
                                onchange="this.nextElementSibling.value = this.checked; ${onchangeHandler}">
                            <input type="hidden" value="${boolValue}" onchange="${onchangeHandler}">
                            <span class="text-xs text-base-content/60">${boolValue ? 'true' : 'false'}</span>
                        </div>
                    `;
                
                case 'integer':
                    return `<input id="${inputId}" type="number" step="1" value="${displayValue}" placeholder="0" class="input input-sm input-bordered flex-1" onchange="${onchangeHandler}">`;
                
                case 'float':
                    return `<input id="${inputId}" type="number" step="0.01" value="${displayValue}" placeholder="0.0" class="input input-sm input-bordered flex-1" onchange="${onchangeHandler}">`;
                
                case 'string':
                    return displayValue.length > 40 ?
                        `<textarea id="${inputId}" class="textarea textarea-sm textarea-bordered min-h-[2rem] flex-1" onchange="${onchangeHandler}">${displayValue}</textarea>` :
                        `<input id="${inputId}" type="text" value="${displayValue}" placeholder="value" class="input input-sm input-bordered flex-1" onchange="${onchangeHandler}">`;
                
                case 'auto':
                default:
                    // Auto mode: use chip-enabled for dynamic field references
                    return displayValue.length > 40 ?
                        `<textarea id="${inputId}" class="textarea textarea-sm textarea-bordered chip-enabled min-h-[2rem] flex-1" onchange="${onchangeHandler}">${displayValue}</textarea>` :
                        `<input id="${inputId}" type="text" value="${displayValue}" placeholder="value" class="input input-sm input-bordered chip-enabled flex-1" onchange="${onchangeHandler}">`;
            }
        }
        
        function renderCreateValues(stepIdx, values) {
            console.log('🔵 [RENDER CREATE] stepIdx:', stepIdx, 'values:', JSON.stringify(values, null, 2));
            const container = document.getElementById(`create-${stepIdx}`);
            container.innerHTML = '';
            
            if (Object.keys(values).length === 0) {
                console.log('🔵 [RENDER CREATE] No values to render');
                return;
            }
            
            // Get field types from metadata
            const fieldTypes = workflowSteps[stepIdx]._ui_metadata?.create_types || {};
            
            console.log('🔵 [RENDER CREATE] Rendering', Object.keys(values).length, 'key/value pairs');
            Object.entries(values).forEach(([key, value]) => {
                const row = document.createElement('div');
                row.className = 'flex items-center gap-2 w-full';
                const displayValue = typeof value === 'object' ? JSON.stringify(value) : value;
                const useTextarea = displayValue.length > 40;
                const fieldType = fieldTypes[key] || 'auto';
                
                console.log('Creating value row:', key, '=', displayValue, 'type:', fieldType);
                
                row.innerHTML = `
                    <input type="text" value="${key}" placeholder="field" data-old-key="${key}" 
                        class="input input-sm input-bordered flex-1"
                        onchange="updateCreateValueFromRow(${stepIdx}, this)">
                    <span class="text-base-content/50 flex-shrink-0">=</span>
                    ${generateValueInput(stepIdx, key, value, fieldType, 'create')}
                    <select class="select select-sm select-bordered flex-shrink-0" onchange="updateCreateFieldType(${stepIdx}, '${key}', this.value); renderCreateValues(${stepIdx}, workflowSteps[${stepIdx}].create);" title="Data type">
                        <option value="auto" ${fieldType === 'auto' ? 'selected' : ''}>Auto</option>
                        <option value="string" ${fieldType === 'string' ? 'selected' : ''}>String</option>
                        <option value="integer" ${fieldType === 'integer' ? 'selected' : ''}>Integer</option>
                        <option value="float" ${fieldType === 'float' ? 'selected' : ''}>Float</option>
                        <option value="boolean" ${fieldType === 'boolean' ? 'selected' : ''}>Boolean</option>
                    </select>
                    <button class="btn btn-sm btn-ghost btn-square flex-shrink-0" onclick="deleteCreateValue(${stepIdx}, '${key}')">×</button>
                `;
                container.appendChild(row);
            });
            
            // Convert ONLY value inputs with auto type (chip-enabled class) to chip inputs
            setTimeout(() => {
                const inputs = container.querySelectorAll('.chip-enabled');
                console.log('Converting', inputs.length, 'auto-type value inputs to chip inputs');
                inputs.forEach(convertToChipInput);
            }, 0);
        }
        
        function addCreateValue(stepIdx) {
            console.log('🟢 [ADD CREATE] stepIdx:', stepIdx);
            console.log('🟢 [ADD CREATE] BEFORE:', JSON.stringify(workflowSteps[stepIdx].create || {}, null, 2));
            
            if (!workflowSteps[stepIdx].create) workflowSteps[stepIdx].create = {};
            
            // Add empty row
            const key = '';
            const value = '';
            workflowSteps[stepIdx].create[key] = value;
            
            // Add only the new row instead of re-rendering everything
            const container = document.getElementById(`create-${stepIdx}`);
            const fieldTypes = workflowSteps[stepIdx]._ui_metadata?.create_types || {};
            const displayValue = '';
            const useTextarea = false;
            const fieldType = 'auto';
            
            const row = document.createElement('div');
            row.className = 'flex items-center gap-2 w-full';
            row.innerHTML = `
                <input type="text" value="" placeholder="field" data-old-key="" 
                    class="input input-sm input-bordered flex-1"
                    onchange="updateCreateValueFromRow(${stepIdx}, this)">
                <span class="text-base-content/50 flex-shrink-0">=</span>
                <input id="create-value-${stepIdx}-new" type="text" value="" placeholder="value" class="input input-sm input-bordered chip-enabled flex-1" onchange="updateCreateValueFromInput(${stepIdx}, '', this)">
                <select class="select select-sm select-bordered flex-shrink-0" onchange="updateCreateFieldType(${stepIdx}, '', this.value)" title="Data type">
                    <option value="auto" selected>Auto</option>
                    <option value="string">String</option>
                    <option value="integer">Integer</option>
                    <option value="float">Float</option>
                    <option value="boolean">Boolean</option>
                </select>
                <button class="btn btn-sm btn-ghost btn-square flex-shrink-0" onclick="deleteCreateValue(${stepIdx}, '')">×</button>
            `;
            container.appendChild(row);
            
            console.log('🟢 [ADD CREATE] AFTER:', JSON.stringify(workflowSteps[stepIdx].create, null, 2));
            
            // Convert only the new input to chip input
            setTimeout(() => {
                const newInput = row.querySelector('.chip-enabled');
                if (newInput) convertToChipInput(newInput);
            }, 0);
            
            // Immediately save after adding new row
            debouncedAutoSave();
        }
        
        function updateCreateValueFromRow(stepIdx, fieldInput) {
            const oldKey = fieldInput.dataset.oldKey;
            const newKey = fieldInput.value;
            
            console.log('🟠 [UPDATE KEY] oldKey:', oldKey, '→ newKey:', newKey);
            
            // Find the value input in the same row
            const row = fieldInput.parentElement;
            
            // Look for hidden input (if chip-enabled) or direct input
            let value = '';
            const hiddenInput = row.querySelector('input[type="hidden"]');
            if (hiddenInput) {
                // Chip input - value is in hidden input
                value = hiddenInput.value;
                // Update the onchange attribute to use the new key
                hiddenInput.setAttribute('onchange', `updateCreateValueFromInput(${stepIdx}, '${newKey}', this)`);
            } else {
                // Normal input or textarea
                const valueInput = row.querySelector('.chip-enabled');
                value = valueInput ? valueInput.value : '';
                // Update the onchange attribute to use the new key
                if (valueInput) {
                    valueInput.setAttribute('onchange', `updateCreateValueFromInput(${stepIdx}, '${newKey}', this)`);
                }
            }
            
            updateCreateValue(stepIdx, oldKey, newKey, value);
            fieldInput.dataset.oldKey = newKey;
        }
        
        function updateCreateValueFromInput(stepIdx, key, inputElement) {
            // Check if this input has been converted to chip input
            // In that case, the actual value is in a hidden input sibling
            const row = inputElement.closest('.flex');
            const hiddenInput = row?.querySelector('input[type="hidden"]');
            
            let value;
            if (hiddenInput) {
                // Chip input - value is in hidden input
                value = hiddenInput.value;
            } else {
                // Normal input or textarea
                value = inputElement.value;
            }
            updateCreateValue(stepIdx, key, key, value);
        }
        
        function updateCreateValue(stepIdx, oldKey, newKey, value) {
            console.log('🟡 [UPDATE CREATE] stepIdx:', stepIdx, 'oldKey:', oldKey, 'newKey:', newKey, 'value:', value);
            console.log('🟡 [UPDATE CREATE] BEFORE:', JSON.stringify(workflowSteps[stepIdx].create, null, 2));
            
            if (oldKey !== newKey) {
                delete workflowSteps[stepIdx].create[oldKey];
                console.log('🟡 [UPDATE CREATE] Deleted old key:', oldKey);
                
                // Sync to SEARCH: rename field
                if (workflowSteps[stepIdx].search?.fields) {
                    const searchIdx = workflowSteps[stepIdx].search.fields.indexOf(oldKey);
                    if (searchIdx !== -1) {
                        workflowSteps[stepIdx].search.fields[searchIdx] = newKey;
                    } else if (newKey && !workflowSteps[stepIdx].search.fields.includes(newKey)) {
                        // Add to search if not exists
                        workflowSteps[stepIdx].search.fields.push(newKey);
                    }
                }
            }
            
            // Parse value based on field type
            const fieldType = workflowSteps[stepIdx]._ui_metadata?.create_types?.[newKey] || 'auto';
            let parsedValue = value;
            
            if (fieldType === 'boolean') {
                // Convert to boolean
                parsedValue = value === 'true' || value === true || value === '1' || value === 1;
            } else if (fieldType === 'integer') {
                parsedValue = parseInt(value, 10) || 0;
            } else if (fieldType === 'float') {
                parsedValue = parseFloat(value) || 0.0;
            } else if (fieldType === 'string') {
                parsedValue = String(value);
            } else {
                // Auto mode: try to detect type
                try {
                    if (value.startsWith('{') || value.startsWith('[') || value === 'true' || value === 'false' || (!isNaN(value) && value !== '')) {
                        parsedValue = JSON.parse(value);
                    }
                } catch (e) {}
            }
            
            workflowSteps[stepIdx].create[newKey] = parsedValue;
            
            console.log('🟡 [UPDATE CREATE] AFTER:', JSON.stringify(workflowSteps[stepIdx].create, null, 2));
        }
        
        function updateCreateFieldType(stepIdx, key, type) {
            if (!workflowSteps[stepIdx]._ui_metadata) workflowSteps[stepIdx]._ui_metadata = {};
            if (!workflowSteps[stepIdx]._ui_metadata.create_types) workflowSteps[stepIdx]._ui_metadata.create_types = {};
            workflowSteps[stepIdx]._ui_metadata.create_types[key] = type;
        }
        
        function deleteCreateValue(stepIdx, key) {
            delete workflowSteps[stepIdx].create[key];
            // Also delete type metadata
            if (workflowSteps[stepIdx]._ui_metadata?.create_types) {
                delete workflowSteps[stepIdx]._ui_metadata.create_types[key];
            }
            
            // Sync to SEARCH: remove field only if it's also not in UPDATE
            if (key && workflowSteps[stepIdx].search?.fields) {
                const inUpdate = workflowSteps[stepIdx].update?.fields?.hasOwnProperty(key);
                if (!inUpdate) {
                    const searchIdx = workflowSteps[stepIdx].search.fields.indexOf(key);
                    if (searchIdx !== -1) {
                        workflowSteps[stepIdx].search.fields.splice(searchIdx, 1);
                        renderSearchFields(stepIdx, workflowSteps[stepIdx].search.fields);
                        renderStepResultChips(stepIdx, workflowSteps[stepIdx]);
                    }
                }
            }
            
            renderCreateValues(stepIdx, workflowSteps[stepIdx].create);
            debouncedAutoSave(); // Trigger auto-save after deletion
        }
        
        // Update Values
        function renderUpdateValues(stepIdx, updateObj) {
            console.log('renderUpdateValues called for step', stepIdx, 'updateObj:', updateObj);
            console.log('updateObj type:', typeof updateObj, 'is array?', Array.isArray(updateObj));
            console.log('updateObj.fields:', updateObj?.fields);
            const container = document.getElementById(`update-${stepIdx}`);
            if (!container) {
                console.error('Update container not found for step', stepIdx);
                return;
            }
            container.innerHTML = '';
            
            // Get search fields as options
            const searchFields = workflowSteps[stepIdx].search?.fields || [];
            const searchFieldOptions = searchFields.length > 0 
                ? searchFields.map(f => `<option value="${f}">${f}</option>`).join('')
                : '';
            
            const values = updateObj.fields || updateObj;
            console.log('Update values to render:', values);
            console.log('Object.keys(values):', Object.keys(values));
            
            if (Object.keys(values).length === 0 || (Object.keys(values).length === 1 && values.enabled !== undefined)) {
                console.log('No values to render for update');
                return;
            }
            
            // Get field types from metadata
            const fieldTypes = workflowSteps[stepIdx]._ui_metadata?.update_types || {};
            
            Object.entries(values).forEach(([key, value]) => {
                if (key === 'enabled') return;
                
                const row = document.createElement('div');
                row.className = 'flex items-center gap-2 w-full';
                const displayValue = typeof value === 'object' ? JSON.stringify(value) : value;
                const useTextarea = displayValue.length > 40;
                const fieldType = fieldTypes[key] || 'auto';
                
                row.innerHTML = `
                    <select class="select select-sm select-bordered flex-1" onchange="updateUpdateValueKey(${stepIdx}, '${key}', this.value)">
                        <option value="">-- Select field --</option>
                        ${searchFieldOptions}
                        <option value="${key}" ${!searchFields.includes(key) && key ? 'selected' : ''}>${key || '(custom)'}</option>
                    </select>
                    <span class="text-base-content/50 flex-shrink-0">=</span>
                    ${generateValueInput(stepIdx, key, value, fieldType, 'update')}
                    <select class="select select-sm select-bordered flex-shrink-0" onchange="updateUpdateFieldType(${stepIdx}, '${key}', this.value); renderUpdateValues(${stepIdx}, workflowSteps[${stepIdx}].update);" title="Data type">
                        <option value="auto" ${fieldType === 'auto' ? 'selected' : ''}>Auto</option>
                        <option value="string" ${fieldType === 'string' ? 'selected' : ''}>String</option>
                        <option value="integer" ${fieldType === 'integer' ? 'selected' : ''}>Integer</option>
                        <option value="float" ${fieldType === 'float' ? 'selected' : ''}>Float</option>
                        <option value="boolean" ${fieldType === 'boolean' ? 'selected' : ''}>Boolean</option>
                    </select>
                    <button class="btn btn-sm btn-ghost btn-square flex-shrink-0" onclick="deleteUpdateValue(${stepIdx}, '${key}')">×</button>
                `;
                container.appendChild(row);
                
                // Set correct selection
                const select = row.querySelector('select');
                if (searchFields.includes(key)) {
                    select.value = key;
                }
            });
            
            // Convert ONLY value inputs with auto type (chip-enabled class) to chip inputs
            setTimeout(() => {
                container.querySelectorAll('.chip-enabled').forEach(convertToChipInput);
            }, 0);
        }
        
        function updateUpdateValueFromInput(stepIdx, key, inputElement) {
            // Check if this has been converted to chip input
            const wrapper = inputElement.parentElement?.classList.contains('relative') ? inputElement.parentElement : null;
            let value;
            if (wrapper) {
                // Chip input - value is in hidden sibling
                const hiddenInput = wrapper.nextElementSibling;
                value = hiddenInput ? hiddenInput.value : inputElement.value;
            } else {
                // Normal input
                value = inputElement.value;
            }
            updateUpdateValue(stepIdx, key, key, value);
        }
        
        function updateUpdateValueKey(stepIdx, oldKey, newKey) {
            if (!workflowSteps[stepIdx].update.fields) workflowSteps[stepIdx].update.fields = {};
            
            const value = workflowSteps[stepIdx].update.fields[oldKey];
            delete workflowSteps[stepIdx].update.fields[oldKey];
            workflowSteps[stepIdx].update.fields[newKey] = value || '';
            
            // Sync to SEARCH: rename or add field
            if (oldKey !== newKey && workflowSteps[stepIdx].search?.fields) {
                const searchIdx = workflowSteps[stepIdx].search.fields.indexOf(oldKey);
                if (searchIdx !== -1) {
                    workflowSteps[stepIdx].search.fields[searchIdx] = newKey;
                } else if (newKey && !workflowSteps[stepIdx].search.fields.includes(newKey)) {
                    workflowSteps[stepIdx].search.fields.push(newKey);
                }
                renderSearchFields(stepIdx, workflowSteps[stepIdx].search.fields);
                renderStepResultChips(stepIdx, workflowSteps[stepIdx]);
            }
            
            renderUpdateValues(stepIdx, workflowSteps[stepIdx].update);
        }
        
        function addUpdateValue(stepIdx) {
            if (!workflowSteps[stepIdx].update) workflowSteps[stepIdx].update = {};
            if (!workflowSteps[stepIdx].update.fields) workflowSteps[stepIdx].update.fields = {};
            
            // Add empty row
            const key = '';
            const value = '';
            workflowSteps[stepIdx].update.fields[key] = value;
            
            // Add only the new row
            const container = document.getElementById(`update-${stepIdx}`);
            const searchFields = workflowSteps[stepIdx].search?.fields || [];
            const searchFieldOptions = searchFields.length > 0 
                ? searchFields.map(f => `<option value="${f}">${f}</option>`).join('')
                : '';
            const fieldTypes = workflowSteps[stepIdx]._ui_metadata?.update_types || {};
            const displayValue = typeof value === 'object' ? JSON.stringify(value) : value;
            const useTextarea = displayValue.length > 40;
            const fieldType = fieldTypes[key] || 'auto';
            
            const row = document.createElement('div');
            row.className = 'flex items-center gap-2 w-full';
            row.innerHTML = `
                <select class="select select-sm select-bordered flex-1" onchange="updateUpdateValueKey(${stepIdx}, '${key}', this.value)">
                    <option value="">-- Select field --</option>
                    ${searchFieldOptions}
                </select>
                <span class="text-base-content/50 flex-shrink-0">=</span>
                <input id="update-value-${stepIdx}-new" type="text" value="${displayValue}" placeholder="value" class="input input-sm input-bordered chip-enabled flex-1" onchange="updateUpdateValueFromInput(${stepIdx}, '', this)">
                <select class="select select-sm select-bordered flex-shrink-0" onchange="updateUpdateFieldType(${stepIdx}, '', this.value)" title="Data type">
                    <option value="auto" selected>Auto</option>
                    <option value="string">String</option>
                    <option value="integer">Integer</option>
                    <option value="float">Float</option>
                    <option value="boolean">Boolean</option>
                </select>
                <button class="btn btn-sm btn-ghost btn-square flex-shrink-0" onclick="deleteUpdateValue(${stepIdx}, '')">×</button>
            `;
            container.appendChild(row);
            
            // Convert only the new input to chip input
            setTimeout(() => {
                const newInput = row.querySelector('.chip-enabled');
                if (newInput) convertToChipInput(newInput);
            }, 0);
            
            // Immediately save after adding new row
            debouncedAutoSave();
        }

        
        function updateUpdateValue(stepIdx, oldKey, newKey, value) {
            if (!workflowSteps[stepIdx].update.fields) workflowSteps[stepIdx].update.fields = {};
            
            if (oldKey !== newKey) {
                delete workflowSteps[stepIdx].update.fields[oldKey];
                
                // Sync to SEARCH: rename or add field
                if (workflowSteps[stepIdx].search?.fields) {
                    const searchIdx = workflowSteps[stepIdx].search.fields.indexOf(oldKey);
                    if (searchIdx !== -1) {
                        workflowSteps[stepIdx].search.fields[searchIdx] = newKey;
                    } else if (newKey && !workflowSteps[stepIdx].search.fields.includes(newKey)) {
                        workflowSteps[stepIdx].search.fields.push(newKey);
                    }
                    renderSearchFields(stepIdx, workflowSteps[stepIdx].search.fields);
                    renderStepResultChips(stepIdx, workflowSteps[stepIdx]);
                }
            }
            
            // Parse value based on field type
            const fieldType = workflowSteps[stepIdx]._ui_metadata?.update_types?.[newKey] || 'auto';
            let parsedValue = value;
            
            if (fieldType === 'boolean') {
                // Convert to boolean
                parsedValue = value === 'true' || value === true || value === '1' || value === 1;
            } else if (fieldType === 'integer') {
                parsedValue = parseInt(value, 10) || 0;
            } else if (fieldType === 'float') {
                parsedValue = parseFloat(value) || 0.0;
            } else if (fieldType === 'string') {
                parsedValue = String(value);
            } else {
                // Auto mode: try to detect type
                try {
                    if (value.startsWith('{') || value.startsWith('[') || value === 'true' || value === 'false' || (!isNaN(value) && value !== '')) {
                        parsedValue = JSON.parse(value);
                    }
                } catch (e) {}
            }
            
            workflowSteps[stepIdx].update.fields[newKey] = parsedValue;
        }
        
        function updateUpdateFieldType(stepIdx, key, type) {
            if (!workflowSteps[stepIdx]._ui_metadata) workflowSteps[stepIdx]._ui_metadata = {};
            if (!workflowSteps[stepIdx]._ui_metadata.update_types) workflowSteps[stepIdx]._ui_metadata.update_types = {};
            workflowSteps[stepIdx]._ui_metadata.update_types[key] = type;
        }
        
        function deleteUpdateValue(stepIdx, key) {
            delete workflowSteps[stepIdx].update.fields[key];
            // Also delete type metadata
            if (workflowSteps[stepIdx]._ui_metadata?.update_types) {
                delete workflowSteps[stepIdx]._ui_metadata.update_types[key];
            }
            
            // Sync to SEARCH: remove field only if it's also not in CREATE
            if (key && workflowSteps[stepIdx].search?.fields) {
                const inCreate = workflowSteps[stepIdx].create?.hasOwnProperty(key);
                if (!inCreate) {
                    const searchIdx = workflowSteps[stepIdx].search.fields.indexOf(key);
                    if (searchIdx !== -1) {
                        workflowSteps[stepIdx].search.fields.splice(searchIdx, 1);
                        renderSearchFields(stepIdx, workflowSteps[stepIdx].search.fields);
                        renderStepResultChips(stepIdx, workflowSteps[stepIdx]);
                    }
                }
            }
            
            renderUpdateValues(stepIdx, workflowSteps[stepIdx].update);
            debouncedAutoSave(); // Trigger auto-save after deletion
        }
        
        // Chatter Message
        function updateChatterMessage(stepIdx, type, message) {
            if (!workflowSteps[stepIdx]._chatter) workflowSteps[stepIdx]._chatter = {};
            workflowSteps[stepIdx]._chatter[type] = message;
            debouncedAutoSave();
        }
        
        // Save & Export
        async function saveForm(silent = false) {
            console.log('🔴 [SAVE FORM START] workflowSteps.length:', workflowSteps.length);
            console.log('🔴 [SAVE FORM START] workflowSteps:', JSON.stringify(workflowSteps, null, 2));
            
            // Convert value_mapping back to Odoo field names and clean up empty mappings
            const cleanedValueMapping = {};
            Object.entries(valueMapping).forEach(([formField, mappings]) => {
                const cleaned = {};
                let hasContent = false;
                
                Object.entries(mappings).forEach(([key, value]) => {
                    if (key.startsWith('_')) {
                        cleaned[key] = value;
                        hasContent = true;
                    } else if (key && value !== undefined) {
                        cleaned[key] = value;
                        hasContent = true;
                    }
                });
                
                if (hasContent) {
                    // Convert forminator field name to odoo field name for storage
                    const odooField = fieldMapping[formField] || formField;
                    cleanedValueMapping[odooField] = cleaned;
                }
            });
            
            // Clean workflow steps: preserve custom domain conditions and template config
            console.log('🟡 [BEFORE MAP] workflowSteps.length:', workflowSteps.length);
            const cleanedWorkflow = workflowSteps.map((step, idx) => {
                const cleanedStep = { ...step };
                
                // Generate final domain from templates + custom conditions FOR EXECUTION
                const finalDomain = generateDomainFromTemplate(idx, step);
                
                // Store custom domain conditions separately (for UI editing on reload)
                if (cleanedStep.search?._customDomain) {
                    // Extract custom domain types to metadata
                    const customDomainTypes = cleanedStep.search._customDomain.map(condition => {
                        return condition[3] || 'text';
                    });
                    
                    if (!cleanedStep._ui_metadata) {
                        cleanedStep._ui_metadata = {};
                    }
                    cleanedStep._ui_metadata.custom_domain_types = customDomainTypes;
                    
                    // Save custom domain (without type info) 
                    cleanedStep.search._customDomain = cleanedStep.search._customDomain.map(condition => {
                        return condition.slice(0, 3);
                    });
                }
                
                // Store the final combined domain (for Odoo execution)
                if (finalDomain && finalDomain.length > 0) {
                    if (!cleanedStep.search) cleanedStep.search = {};
                    cleanedStep.search.domain = finalDomain.map(condition => {
                        return condition.slice(0, 3);
                    });
                } else {
                    // Clear domain if no conditions
                    if (cleanedStep.search) {
                        cleanedStep.search.domain = [];
                    }
                }
                
                return cleanedStep;
            });
            
            // Get current form name from input
            const formNameInput = document.getElementById('formName');
            const currentFormName = formNameInput ? formNameInput.value.trim() : (mappings[currentFormId]?.name || '');
            
            // Preserve metadata but don't send it in the update
            const existingMetadata = mappings[currentFormId]?._metadata;
            const existingHtmlCard = mappings[currentFormId]?.html_card;
            
            const data = {
                name: currentFormName,
                field_mapping: fieldMapping,
                value_mapping: cleanedValueMapping,
                workflow: cleanedWorkflow,
                html_card: existingHtmlCard
            };
            
            // Include version for optimistic locking if available
            if (existingMetadata?.version !== undefined) {
                data._version = existingMetadata.version;
            }
            
            console.log('🟢 [DATA TO SAVE] workflowSteps count:', workflowSteps.length);
            console.log('🟢 [DATA TO SAVE] cleanedWorkflow count:', cleanedWorkflow.length);
            console.log('🟢 [DATA TO SAVE] data.workflow count:', data.workflow.length);
            console.log('Saving form data:', JSON.stringify(data, null, 2));
            console.log('Original workflowSteps:', JSON.stringify(workflowSteps, null, 2));
            
            try {
                const response = await apiCall(`/api/mappings/${currentFormId}`, {
                    method: 'POST',
                    body: JSON.stringify(data)
                });
                
                // Handle different response statuses
                if (response.status === 409) {
                    // Version conflict - reload the form to get latest version
                    const result = await response.json();
                    if (!silent) {
                        showAlert('Form was modified by another user. Reloading...', 'warning');
                    }
                    // Reload the form to get the latest version
                    await loadFormForEdit(currentFormId);
                    updateSaveStatus('error');
                    return;
                }
                
                if (!response.ok) {
                    const error = await response.json();
                    throw new Error(error.error || error.message || 'Failed to save');
                }
                
                const result = await response.json();
                
                // Update local mappings with response data (includes updated metadata)
                if (result.success && result.data) {
                    mappings[currentFormId] = result.data;
                    console.log('📝 Updated local mapping with new version:', result.data._metadata?.version);
                } else {
                    // Fallback: preserve old metadata
                    mappings[currentFormId] = { ...data, _metadata: existingMetadata };
                }
                
                if (!silent) {
                    console.log('Form saved successfully, mappings updated:', mappings[currentFormId]);
                    showAlert('Form saved successfully', 'success');
                }
                updateSaveStatus('saved');
            } catch (err) {
                console.error('Save error:', err);
                if (!silent) {
                    showAlert('Failed to save: ' + err.message, 'error');
                }
                updateSaveStatus('error');
            }
        }
        
        function exportForm() {
            const data = mappings[currentFormId];
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `form_${currentFormId}.json`;
            a.click();
        }
        
        async function deleteForm() {
            if (!confirm(`Delete form ${currentFormId}?`)) return;
            
            try {
                await apiCall(`/api/mappings/${currentFormId}`, { method: 'DELETE' });
                delete mappings[currentFormId];
                showAlert('Form deleted', 'success');
                loadForms();
                document.getElementById('editorContent').innerHTML = '';
            } catch (err) {
                showAlert('Failed to delete: ' + err.message, 'error');
            }
        }
        
        function updateFormName() {
            const newName = document.getElementById('formName').value.trim();
            if (!currentFormId) return;
            
            if (!mappings[currentFormId]) {
                mappings[currentFormId] = { field_mapping: {}, value_mapping: {}, workflow: [] };
            }
            
            mappings[currentFormId].name = newName;
            document.getElementById('editorTitle').textContent = `Edit: ${newName || currentFormId}`;
            
            // Update list item text directly without reloading from server
            const list = document.getElementById('formList');
            const activeItem = list.querySelector('.active');
            if (activeItem) {
                activeItem.textContent = newName || currentFormId;
                activeItem.title = `ID: ${currentFormId}`;
            }
        }
        
        function createNewForm() {
            const formId = prompt('Enter Forminator Form ID:');
            if (!formId) return;
            
            if (mappings[formId]) {
                showAlert('Form ID already exists!', 'error');
                return;
            }
            
            const formName = prompt('Enter Form Name (display name):', formId);
            
            // Create new empty form
            currentFormId = formId;
            fieldMapping = {};
            valueMapping = {};
            workflowSteps = [];
            expandedValueMappings = {};
            
            mappings[formId] = {
                name: formName || formId,
                field_mapping: {},
                value_mapping: {},
                workflow: []
            };
            
            // Reload forms list to show new form with name
            loadForms();
            
            // Load in editor
            loadForm(formId);
            showAlert(`Created new form: ${formName || formId}`, 'success');
        }
        
        // HTML Card Editor Functions
        
        function openHtmlCardEditor(stepIdx) {
            currentHtmlCardStepIdx = stepIdx;
            const modal = document.getElementById('htmlCardModal');
            const step = workflowSteps[stepIdx];
            const isEditing = !!step.html_card;
            
            // Update modal title
            const modalTitle = document.querySelector('#htmlCardModal .font-bold');
            if (modalTitle) {
                modalTitle.innerHTML = `${isEditing ? '✏️ Edit' : '➕ Create'} HTML Card`;
            }
            
            // Load existing config or start fresh
            if (step.html_card) {
                try {
                    const existingConfig = JSON.parse(step.html_card);
                    htmlCardSections = existingConfig.sections || [];
                    
                    // Load style options
                    const style = existingConfig.style || {};
                    if (document.getElementById('htmlCardCompact')) {
                        document.getElementById('htmlCardCompact').checked = style.compact || false;
                    }
                    if (document.getElementById('htmlCardBorders')) {
                        document.getElementById('htmlCardBorders').checked = style.borders !== false;
                    }
                    if (document.getElementById('htmlCardIcons')) {
                        document.getElementById('htmlCardIcons').checked = style.icons !== false;
                    }
                } catch (e) {
                    console.error('Error loading HTML card config:', e);
                    htmlCardSections = [];
                }
            } else {
                htmlCardSections = [];
                // Reset style options to defaults
                if (document.getElementById('htmlCardCompact')) {
                    document.getElementById('htmlCardCompact').checked = false;
                }
                if (document.getElementById('htmlCardBorders')) {
                    document.getElementById('htmlCardBorders').checked = true;
                }
                if (document.getElementById('htmlCardIcons')) {
                    document.getElementById('htmlCardIcons').checked = true;
                }
            }
            
            // Populate field checkboxes
            populateHtmlCardFieldSelector();
            
            // Update preview
            updateHtmlCardPreview();
            
            // Show modal
            if (modal && typeof modal.showModal === 'function') {
                modal.showModal();
                // Reinitialize icons after modal opens
                setTimeout(() => {
                    if (typeof lucide !== 'undefined') {
                        lucide.createIcons();
                    }
                }, 100);
            }
        }
        
        function closeHtmlCardEditor() {
            const modal = document.getElementById('htmlCardModal');
            if (modal && typeof modal.close === 'function') {
                modal.close();
            }
            currentHtmlCardStepIdx = null;
            htmlCardSections = [];
        }
        
        function addHtmlCardSection(type) {
            if (type === 'title') {
                htmlCardSections.push({
                    type: 'title',
                    text: 'Section Title'
                });
            } else if (type === 'divider') {
                htmlCardSections.push({
                    type: 'divider'
                });
            } else if (type === 'text') {
                htmlCardSections.push({
                    type: 'text',
                    content: 'Add your text here...'
                });
            } else if (type === 'columnBreak') {
                htmlCardSections.push({
                    type: 'columnBreak',
                    columns: 1
                });
            }
            populateHtmlCardFieldSelector();
            updateHtmlCardPreview();
        }
        
        function removeHtmlCardSection(index) {
            htmlCardSections.splice(index, 1);
            populateHtmlCardFieldSelector();
            updateHtmlCardPreview();
        }
        
        function moveHtmlCardSectionUp(index) {
            if (index > 0) {
                const temp = htmlCardSections[index];
                htmlCardSections[index] = htmlCardSections[index - 1];
                htmlCardSections[index - 1] = temp;
                populateHtmlCardFieldSelector();
                updateHtmlCardPreview();
            }
        }
        
        function moveHtmlCardSectionDown(index) {
            if (index < htmlCardSections.length - 1) {
                const temp = htmlCardSections[index];
                htmlCardSections[index] = htmlCardSections[index + 1];
                htmlCardSections[index + 1] = temp;
                populateHtmlCardFieldSelector();
                updateHtmlCardPreview();
            }
        }
        
        function updateHtmlCardSectionText(index, text) {
            if (htmlCardSections[index]) {
                htmlCardSections[index].text = text;
                updateHtmlCardPreview();
            }
        }
        
        function updateHtmlCardSectionContent(index, content) {
            if (htmlCardSections[index]) {
                htmlCardSections[index].content = content;
                updateHtmlCardPreview();
            }
        }
        
        function updateHtmlCardSectionColumns(index, columns) {
            if (htmlCardSections[index]) {
                htmlCardSections[index].columns = parseInt(columns);
                updateHtmlCardPreview();
            }
        }
        
        function updateHtmlCardFieldLabel(fieldName, newLabel) {
            const section = htmlCardSections.find(s => s.type === 'field' && s.field === fieldName);
            if (section) {
                section.customLabel = newLabel;
                updateHtmlCardPreview();
            }
        }
        
        function populateHtmlCardFieldSelector() {
            const container = document.getElementById('htmlCardFieldSelector');
            container.innerHTML = '';
            
            // Get all mapped fields
            const availableFields = Object.entries(fieldMapping).filter(([k]) => !k.startsWith('_'));
            
            if (availableFields.length === 0) {
                container.innerHTML = '<div class="text-sm text-base-content/60 italic">No fields mapped yet</div>';
                return;
            }
            
            // Show existing sections (fields, titles, dividers, text, columnBreaks)
            htmlCardSections.forEach((section, idx) => {
                const div = document.createElement('div');
                
                if (section.type === 'title') {
                    div.className = 'bg-base-200 rounded p-2 mb-1';
                    div.innerHTML = `
                        <div class="flex items-center gap-1">
                            <div class="flex flex-col">
                                <button class="btn btn-ghost btn-xs p-0 h-3 min-h-0" onclick="moveHtmlCardSectionUp(${idx})" ${idx === 0 ? 'disabled' : ''}>▲</button>
                                <button class="btn btn-ghost btn-xs p-0 h-3 min-h-0" onclick="moveHtmlCardSectionDown(${idx})" ${idx === htmlCardSections.length - 1 ? 'disabled' : ''}>▼</button>
                            </div>
                            <i data-lucide="heading" class="w-3 h-3"></i>
                            <input type="text" 
                                   value="${section.text || 'Title'}" 
                                   class="input input-xs flex-1" 
                                   onchange="updateHtmlCardSectionText(${idx}, this.value)"
                                   placeholder="Title text">
                            <button class="btn btn-ghost btn-xs" onclick="removeHtmlCardSection(${idx})">×</button>
                        </div>
                    `;
                } else if (section.type === 'divider') {
                    div.className = 'bg-base-200 rounded p-2 mb-1';
                    div.innerHTML = `
                        <div class="flex items-center gap-1">
                            <div class="flex flex-col">
                                <button class="btn btn-ghost btn-xs p-0 h-3 min-h-0" onclick="moveHtmlCardSectionUp(${idx})" ${idx === 0 ? 'disabled' : ''}>▲</button>
                                <button class="btn btn-ghost btn-xs p-0 h-3 min-h-0" onclick="moveHtmlCardSectionDown(${idx})" ${idx === htmlCardSections.length - 1 ? 'disabled' : ''}>▼</button>
                            </div>
                            <i data-lucide="minus" class="w-3 h-3"></i>
                            <span class="text-xs flex-1">Divider</span>
                            <button class="btn btn-ghost btn-xs" onclick="removeHtmlCardSection(${idx})">×</button>
                        </div>
                    `;
                } else if (section.type === 'text') {
                    div.className = 'bg-info/10 rounded p-2 mb-1';
                    div.innerHTML = `
                        <div class="flex items-center gap-1 mb-1">
                            <div class="flex flex-col">
                                <button class="btn btn-ghost btn-xs p-0 h-3 min-h-0" onclick="moveHtmlCardSectionUp(${idx})" ${idx === 0 ? 'disabled' : ''}>▲</button>
                                <button class="btn btn-ghost btn-xs p-0 h-3 min-h-0" onclick="moveHtmlCardSectionDown(${idx})" ${idx === htmlCardSections.length - 1 ? 'disabled' : ''}>▼</button>
                            </div>
                            <i data-lucide="text" class="w-3 h-3"></i>
                            <span class="text-xs flex-1">Text Block</span>
                            <button class="btn btn-ghost btn-xs" onclick="removeHtmlCardSection(${idx})">×</button>
                        </div>
                        <textarea 
                            class="textarea textarea-xs w-full" 
                            rows="2"
                            onchange="updateHtmlCardSectionContent(${idx}, this.value)"
                            placeholder="Your text here...">${section.content || ''}</textarea>
                    `;
                } else if (section.type === 'columnBreak') {
                    div.className = 'bg-warning/10 rounded p-2 mb-1';
                    div.innerHTML = `
                        <div class="flex items-center gap-1">
                            <div class="flex flex-col">
                                <button class="btn btn-ghost btn-xs p-0 h-3 min-h-0" onclick="moveHtmlCardSectionUp(${idx})" ${idx === 0 ? 'disabled' : ''}>▲</button>
                                <button class="btn btn-ghost btn-xs p-0 h-3 min-h-0" onclick="moveHtmlCardSectionDown(${idx})" ${idx === htmlCardSections.length - 1 ? 'disabled' : ''}>▼</button>
                            </div>
                            <i data-lucide="columns" class="w-3 h-3"></i>
                            <span class="text-xs flex-1">New Group</span>
                            <select class="select select-xs" onchange="updateHtmlCardSectionColumns(${idx}, this.value)">
                                <option value="1" ${section.columns === 1 ? 'selected' : ''}>1 Column</option>
                                <option value="2" ${section.columns === 2 ? 'selected' : ''}>2 Columns</option>
                            </select>
                            <button class="btn btn-ghost btn-xs" onclick="removeHtmlCardSection(${idx})">×</button>
                        </div>
                    `;
                } else if (section.type === 'field') {
                    div.className = 'bg-primary/10 rounded p-2 mb-1';
                    div.innerHTML = `
                        <div class="flex items-center gap-1 mb-1">
                            <div class="flex flex-col">
                                <button class="btn btn-ghost btn-xs p-0 h-3 min-h-0" onclick="moveHtmlCardSectionUp(${idx})" ${idx === 0 ? 'disabled' : ''}>▲</button>
                                <button class="btn btn-ghost btn-xs p-0 h-3 min-h-0" onclick="moveHtmlCardSectionDown(${idx})" ${idx === htmlCardSections.length - 1 ? 'disabled' : ''}>▼</button>
                            </div>
                            <i data-lucide="tag" class="w-3 h-3"></i>
                            <span class="text-xs font-semibold flex-1">${section.field}</span>
                            <button class="btn btn-ghost btn-xs" onclick="removeHtmlCardSection(${idx})">×</button>
                        </div>
                        <input type="text" 
                               value="${section.customLabel || section.field.replace(/_/g, ' ')}" 
                               class="input input-xs w-full" 
                               onchange="updateHtmlCardFieldLabel('${section.field}', this.value)"
                               placeholder="Custom label">
                    `;
                }
                
                container.appendChild(div);
            });
            
            // Divider before available fields
            if (htmlCardSections.length > 0 && availableFields.length > 0) {
                const divider = document.createElement('div');
                divider.className = 'divider my-2 text-xs';
                divider.textContent = 'Available Fields';
                container.appendChild(divider);
            }
            
            // Show available fields (not yet added)
            const addedFields = htmlCardSections.filter(s => s.type === 'field').map(s => s.field);
            availableFields.forEach(([formField, odooField]) => {
                if (!addedFields.includes(odooField)) {
                    const div = document.createElement('div');
                    div.className = 'form-control';
                    div.innerHTML = `
                        <button class="btn btn-xs btn-ghost justify-start gap-2" onclick="addHtmlCardField('${odooField}')">
                            <i data-lucide="plus" class="w-3 h-3"></i>
                            <span class="text-sm">${odooField}</span>
                        </button>
                    `;
                    container.appendChild(div);
                }
            });
            
            // Reinitialize icons
            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            }
        }
        
        function addHtmlCardField(fieldName) {
            htmlCardSections.push({
                type: 'field',
                field: fieldName,
                customLabel: null
            });
            populateHtmlCardFieldSelector();
            updateHtmlCardPreview();
        }
        
        function applyHtmlCardTemplate(templateName) {
            // Get all available fields
            const allFields = Object.values(fieldMapping).filter(v => v && !v.startsWith('_'));
            
            switch (templateName) {
                case 'contact':
                    htmlCardSelectedFields = allFields.filter(f => 
                        ['first_name', 'last_name', 'name', 'email', 'phone', 'mobile', 'street', 'city', 'zip'].includes(f)
                    );
                    break;
                case 'property':
                    htmlCardSelectedFields = allFields.filter(f => 
                        ['street', 'number', 'city', 'zip', 'number_of_units', 'ownership_type'].includes(f)
                    );
                    break;
                case 'summary':
                    htmlCardSelectedFields = allFields.slice(0, 5); // First 5 fields
                    break;
                case 'detailed':
                    htmlCardSelectedFields = [...allFields]; // All fields
                    break;
                case 'simple':
                    htmlCardSelectedFields = allFields.slice(0, 3); // First 3 fields
                    break;
                case 'blank':
                    htmlCardSelectedFields = [];
                    break;
            }
            
            // Update UI
            populateHtmlCardFieldSelector();
            updateHtmlCardPreview();
        }
        
        function updateHtmlCardPreview() {
            const preview = document.getElementById('htmlCardPreview');
            
            if (!htmlCardSections || htmlCardSections.length === 0) {
                preview.innerHTML = '<div class="text-sm text-base-content/60 italic p-4">No fields selected</div>';
                return;
            }
            
            // Get style options
            const compact = document.getElementById('htmlCardCompact')?.checked || false;
            const borders = document.getElementById('htmlCardBorders')?.checked || false;
            const showIcons = document.getElementById('htmlCardIcons')?.checked || true;
            
            let html = '<div style="padding:20px; background:#f9fafb; border-radius:8px; font-family:system-ui,-apple-system,sans-serif;">';
            
            // Track if we're in a grid section
            let gridItems = [];
            let currentColumns = 1;
            
            htmlCardSections.forEach((section, idx) => {
                if (section.type === 'title') {
                    // Close previous grid if exists
                    if (gridItems.length > 0) {
                        html += `<div style="display:grid; grid-template-columns: repeat(${currentColumns}, 1fr); gap:${compact ? '8px' : '12px'}; margin-bottom:${compact ? '16px' : '20px'};">`;
                        html += gridItems.join('');
                        html += '</div>';
                        gridItems = [];
                    }
                    
                    html += `<h3 style="font-size:${compact ? '14px' : '16px'}; font-weight:600; color:#374151; margin:${compact ? '12px' : '16px'} 0 ${compact ? '8px' : '12px'} 0; ${idx === 0 ? 'margin-top:0;' : ''}">${section.text || 'Section'}</h3>`;
                } else if (section.type === 'divider') {
                    // Close previous grid if exists
                    if (gridItems.length > 0) {
                        html += `<div style="display:grid; grid-template-columns: repeat(${currentColumns}, 1fr); gap:${compact ? '8px' : '12px'}; margin-bottom:${compact ? '16px' : '20px'};">`;
                        html += gridItems.join('');
                        html += '</div>';
                        gridItems = [];
                    }
                    
                    html += `<hr style="border:none; border-top:1px solid #e5e7eb; margin:${compact ? '12px' : '16px'} 0;">`;
                } else if (section.type === 'text') {
                    // Close previous grid if exists
                    if (gridItems.length > 0) {
                        html += `<div style="display:grid; grid-template-columns: repeat(${currentColumns}, 1fr); gap:${compact ? '8px' : '12px'}; margin-bottom:${compact ? '16px' : '20px'};">`;
                        html += gridItems.join('');
                        html += '</div>';
                        gridItems = [];
                    }
                    
                    html += `<div style="background:white; padding:${compact ? '10px' : '14px'}; border-radius:6px; ${borders ? 'border:1px solid #e5e7eb;' : ''} margin-bottom:${compact ? '12px' : '16px'}; white-space:pre-wrap; color:#374151; font-size:${compact ? '12px' : '14px'};">${section.content || 'Text...'}</div>`;
                } else if (section.type === 'columnBreak') {
                    // Close previous grid if exists
                    if (gridItems.length > 0) {
                        html += `<div style="display:grid; grid-template-columns: repeat(${currentColumns}, 1fr); gap:${compact ? '8px' : '12px'}; margin-bottom:${compact ? '16px' : '20px'};">`;
                        html += gridItems.join('');
                        html += '</div>';
                        gridItems = [];
                    }
                    
                    // Update column count for next group
                    currentColumns = section.columns || 1;
                } else if (section.type === 'field') {
                    const label = section.customLabel || section.field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                    const iconMap = {
                        email: 'mail',
                        phone: 'phone',
                        mobile: 'smartphone',
                        name: 'user',
                        street: 'map-pin',
                        city: 'map',
                        zip: 'hash',
                        country: 'globe'
                    };
                    const icon = iconMap[section.field.toLowerCase()] || 'tag';
                    
                    let itemHtml = `
                        <div style="background:white; padding:${compact ? '8px' : '12px'}; border-radius:6px; ${borders ? 'border:1px solid #e5e7eb;' : ''}">
                            <div style="display:flex; align-items:center; gap:6px; margin-bottom:4px;">
                                ${showIcons ? `<i data-lucide="${icon}" style="width:14px; height:14px; color:#6b7280;"></i>` : ''}
                                <div style="font-size:${compact ? '11px' : '12px'}; color:#6b7280; font-weight:500;">${label}</div>
                            </div>
                            <div style="font-size:${compact ? '13px' : '14px'}; color:#111827; font-weight:500;">\${${section.field}}</div>
                        </div>
                    `;
                    
                    gridItems.push(itemHtml);
                }
            });
            
            // Close final grid if exists
            if (gridItems.length > 0) {
                html += `<div style="display:grid; grid-template-columns: repeat(${currentColumns}, 1fr); gap:${compact ? '8px' : '12px'};">`;
                html += gridItems.join('');
                html += '</div>';
            }
            
            html += '</div>';
            preview.innerHTML = html;
            
            // Reinitialize icons
            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            }
        }
        
        function saveHtmlCard() {
            const compact = document.getElementById('htmlCardCompact')?.checked || false;
            const borders = document.getElementById('htmlCardBorders')?.checked || false;
            const showIcons = document.getElementById('htmlCardIcons')?.checked || true;
            
            const config = {
                sections: htmlCardSections,
                style: { 
                    compact, 
                    borders, 
                    icons: showIcons
                }
            };
            
            // Generate the actual HTML that will be used
            workflowSteps[currentHtmlCardStepIdx].html_card = JSON.stringify(config);
            
            // Also set the description field to use __html_card__
            if (!workflowSteps[currentHtmlCardStepIdx].create) {
                workflowSteps[currentHtmlCardStepIdx].create = {};
            }
            workflowSteps[currentHtmlCardStepIdx].create.description = '__html_card__';
            
            console.log('Saved HTML card config:', config);
            
            // Close modal and refresh UI
            closeHtmlCardEditor();
            renderWorkflowSteps();
            
            // Show success message
            alert('✅ HTML Card saved successfully!');
        }
        
        function showHistoryDetail(idx) {
            const canvas = document.getElementById('htmlCardCanvas');
            const draggables = document.querySelectorAll('.html-card-draggable');
            
            draggables.forEach(draggable => {
                draggable.addEventListener('dragstart', (e) => {
                    e.dataTransfer.setData('type', draggable.dataset.type);
                    if (draggable.dataset.field) {
                        e.dataTransfer.setData('field', draggable.dataset.field);
                    }
                    if (draggable.dataset.odooField) {
                        e.dataTransfer.setData('odooField', draggable.dataset.odooField);
                    }
                    draggable.classList.add('dragging');
                });
                
                draggable.addEventListener('dragend', (e) => {
                    draggable.classList.remove('dragging');
                });
            });
            
            canvas.addEventListener('dragover', (e) => {
                e.preventDefault();
                canvas.classList.add('dragover');
            });
            
            canvas.addEventListener('dragleave', () => {
                canvas.classList.remove('dragover');
            });
            
            canvas.addEventListener('drop', (e) => {
                e.preventDefault();
                canvas.classList.remove('dragover');
                
                // Check if dropping into a container (not the canvas itself)
                const containerElement = e.target.closest('[data-container-id]');
                if (containerElement && containerElement !== canvas) {
                    return; // Let container handle it
                }
                
                const existingPath = e.dataTransfer.getData('existingPath');
                if (existingPath) {
                    // Moving existing element to root
                    const path = JSON.parse(existingPath);
                    moveHtmlCardElement(path, null);
                } else {
                    // Adding new element to root
                    const type = e.dataTransfer.getData('type');
                    const field = e.dataTransfer.getData('field');
                    const odooField = e.dataTransfer.getData('odooField');
                    addHtmlCardElement(type, field, odooField, null);
                }
            });
        }
        
        function addHtmlCardElement(type, field = null, odooField = null, containerId = null) {
            const element = {
                id: Date.now() + Math.random(),
                type: type,
                field: field,
                odooField: odooField
            };
            
            // Add default values based on type
            if (type === 'heading') {
                element.text = 'Heading Text';
                element.level = 'h2';
            } else if (type === 'text') {
                element.text = 'Text content here...';
            } else if (type === 'divider') {
                // No extra properties
            } else if (type === 'container') {
                element.title = 'Container Title';
                element.layout = 'vertical'; // or 'horizontal', 'grid'
                element.children = [];
            } else if (type === 'field' || type === 'step-field') {
                element.label = odooField || field;
                console.log('Created field element:', element);
            }
            
            // Add to container or root
            if (containerId) {
                const container = findElementById(containerId);
                if (container && container.children) {
                    container.children.push(element);
                }
            } else {
                htmlCardElements.push(element);
            }
            
            renderHtmlCardCanvas();
        }
        
        function findElementById(id) {
            for (const el of htmlCardElements) {
                if (el.id === id) return el;
                if (el.children) {
                    const found = findInChildren(el.children, id);
                    if (found) return found;
                }
            }
            return null;
        }
        
        function findInChildren(children, id) {
            for (const child of children) {
                if (child.id === id) return child;
                if (child.children) {
                    const found = findInChildren(child.children, id);
                    if (found) return found;
                }
            }
            return null;
        }
        
        function moveHtmlCardElement(fromPath, toContainerId) {
            // Get the element
            let source = htmlCardElements;
            for (let i = 0; i < fromPath.length - 1; i++) {
                source = source[fromPath[i]];
            }
            const element = source[fromPath[fromPath.length - 1]];
            
            // Remove from old location
            source.splice(fromPath[fromPath.length - 1], 1);
            
            // Add to new location
            if (toContainerId) {
                const container = findElementById(toContainerId);
                if (container && container.children) {
                    container.children.push(element);
                }
            } else {
                htmlCardElements.push(element);
            }
            
            renderHtmlCardCanvas();
        }
        
        function renderHtmlCardCanvas() {
            const canvas = document.getElementById('htmlCardCanvas');
            
            if (htmlCardElements.length === 0) {
                canvas.innerHTML = '<p style="color: #999; text-align: center; margin-top: 2rem;">Drag elements here to build your HTML card</p>';
                return;
            }
            
            canvas.innerHTML = '';
            renderElements(htmlCardElements, canvas, []);
        }
        
        function renderElements(elements, container, path) {
            elements.forEach((element, idx) => {
                const currentPath = [...path, idx];
                const div = document.createElement('div');
                div.className = 'html-card-element';
                
                if (element.type === 'container') {
                    div.classList.add('html-card-container');
                }
                
                // Serialize path as JSON string for safe passing to functions
                const pathJson = JSON.stringify(currentPath);
                const pathStr = pathJson.replace(/"/g, '&quot;');
                
                // Create drag handle
                const dragHandle = document.createElement('div');
                dragHandle.className = 'html-card-element-drag-handle';
                dragHandle.draggable = true;
                
                dragHandle.addEventListener('dragstart', (e) => {
                    e.stopPropagation();
                    e.dataTransfer.setData('existingPath', JSON.stringify(currentPath));
                    div.style.opacity = '0.5';
                });
                dragHandle.addEventListener('dragend', (e) => {
                    div.style.opacity = '1';
                });
                
                div.appendChild(dragHandle);
                
                // Create controls
                const controls = document.createElement('div');
                controls.className = 'html-card-element-controls';
                controls.innerHTML = '<button data-path="' + pathJson + '" onclick="removeHtmlCardElementByPathJson(this.getAttribute(\'data-path\'))" title="Remove">×</button>';
                div.appendChild(controls);
                
                // Create content
                const content = document.createElement('div');
                content.innerHTML = renderHtmlCardElementPreview(element, currentPath);
                div.appendChild(content);
                
                // Render children if it's a container
                if (element.type === 'container') {
                    // Initialize children array if it doesn't exist
                    if (!element.children) {
                        element.children = [];
                    }
                    
                    const childrenContainer = document.createElement('div');
                    childrenContainer.className = 'html-card-container-children';
                    childrenContainer.setAttribute('data-container-id', element.id);
                    childrenContainer.style.cssText = element.layout === 'horizontal' 
                        ? 'display: flex; gap: 0.5rem; flex-wrap: wrap;' 
                        : element.layout === 'grid'
                        ? 'display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem;'
                        : 'display: flex; flex-direction: column; gap: 0.5rem;';
                    
                    // Show empty state if no children
                    if (element.children.length === 0) {
                        const emptyState = document.createElement('div');
                        emptyState.style.cssText = 'padding: 1rem; background: #f0f4ff; border: 2px dashed #667eea; border-radius: 4px; text-align: center; min-height: 80px; display: flex; align-items: center; justify-content: center;';
                        emptyState.innerHTML = '<small style="color: #667eea; font-weight: 500;">📦 Sleep elementen hierheen</small>';
                        childrenContainer.appendChild(emptyState);
                    }
                    
                    // Add drop zone handlers
                    childrenContainer.addEventListener('dragover', (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        childrenContainer.classList.add('dragover');
                    });
                    childrenContainer.addEventListener('dragleave', (e) => {
                        e.stopPropagation();
                        childrenContainer.classList.remove('dragover');
                    });
                    childrenContainer.addEventListener('drop', (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        childrenContainer.classList.remove('dragover');
                        
                        const existingPath = e.dataTransfer.getData('existingPath');
                        if (existingPath) {
                            // Moving existing element
                            const path = JSON.parse(existingPath);
                            moveHtmlCardElement(path, element.id);
                        } else {
                            // Adding new element
                            const type = e.dataTransfer.getData('type');
                            const field = e.dataTransfer.getData('field');
                            const odooField = e.dataTransfer.getData('odooField');
                            addHtmlCardElement(type, field, odooField, element.id);
                        }
                    });
                    
                    div.appendChild(childrenContainer);
                    if (element.children.length > 0) {
                        renderElements(element.children, childrenContainer, currentPath.concat(['children']));
                    }
                }
                
                container.appendChild(div);
            });
        }
        
        function renderHtmlCardElementPreview(element, path) {
            const pathStr = path.join(',');
            
            if (element.type === 'heading') {
                const pathJson = JSON.stringify(path);
                return `
                    <input type="text" value="${element.text}" data-path='${pathJson}' 
                        oninput="updateHtmlCardElementByPathJson(this.getAttribute('data-path'), 'text', this.value, true)" 
                        onchange="updateHtmlCardElementByPathJson(this.getAttribute('data-path'), 'text', this.value, false)" 
                        style="width: 100%; font-size: 1.2rem; font-weight: bold; border: 1px solid #ddd; padding: 0.5rem; border-radius: 4px;">
                    <select data-path='${pathJson}' class="select select-sm select-bordered w-full mt-2" onchange="updateHtmlCardElementByPathJson(this.getAttribute('data-path'), 'level', this.value, false)">
                        <option value="h1" ${element.level === 'h1' ? 'selected' : ''}>H1</option>
                        <option value="h2" ${element.level === 'h2' ? 'selected' : ''}>H2</option>
                        <option value="h3" ${element.level === 'h3' ? 'selected' : ''}>H3</option>
                    </select>
                `;
            } else if (element.type === 'text') {
                const pathJson = JSON.stringify(path);
                return `
                    <textarea data-path='${pathJson}' 
                        oninput="updateHtmlCardElementByPathJson(this.getAttribute('data-path'), 'text', this.value, true)" 
                        onchange="updateHtmlCardElementByPathJson(this.getAttribute('data-path'), 'text', this.value, false)" 
                        style="width: 100%; min-height: 60px; border: 1px solid #ddd; padding: 0.5rem; border-radius: 4px; font-family: inherit;">${element.text}</textarea>
                `;
            } else if (element.type === 'divider') {
                return '<hr style="border: none; border-top: 2px solid #ddd; margin: 0.5rem 0;">';
            } else if (element.type === 'container') {
                const pathJson = JSON.stringify(path);
                return `
                    <div style="margin-bottom: 0.5rem;">
                        <input type="text" value="${element.title}" data-path='${pathJson}' 
                            oninput="updateHtmlCardElementByPathJson(this.getAttribute('data-path'), 'title', this.value, true)" 
                            onchange="updateHtmlCardElementByPathJson(this.getAttribute('data-path'), 'title', this.value, false)" 
                            style="width: 100%; font-weight: 600; border: 1px solid #ddd; padding: 0.5rem; border-radius: 4px;">
                    </div>
                    <select data-path='${pathJson}' class="select select-sm select-bordered w-full" onchange="updateHtmlCardElementByPathJson(this.getAttribute('data-path'), 'layout', this.value, false)">
                        <option value="vertical" ${element.layout === 'vertical' ? 'selected' : ''}>Vertical</option>
                        <option value="horizontal" ${element.layout === 'horizontal' ? 'selected' : ''}>Horizontal</option>
                        <option value="grid" ${element.layout === 'grid' ? 'selected' : ''}>Grid (2 columns)</option>
                    </select>
                `;
            } else if (element.type === 'field' || element.type === 'step-field') {
                const labelValue = escapeHtml(element.label || element.odooField || element.field);
                const pathJson = JSON.stringify(path);
                return `
                    <div style="display: flex; gap: 0.5rem; align-items: center;">
                        <input type="text" value="${labelValue}" 
                            data-path='${pathJson}'
                            oninput="updateHtmlCardElementByPathJson(this.getAttribute('data-path'), 'label', this.value, true)" 
                            onchange="updateHtmlCardElementByPathJson(this.getAttribute('data-path'), 'label', this.value, false)" 
                            placeholder="Label" style="flex: 1; border: 1px solid #ddd; padding: 0.5rem; border-radius: 4px;">
                        <span class="${element.type === 'step-field' ? 'step-chip' : 'field-chip'}" style="flex-shrink: 0;">
                            ${element.odooField || element.field}
                        </span>
                    </div>
                `;
            }
            return '';
        }
        
        function updateHtmlCardElementByPathJson(pathJson, property, value, skipRender) {
            const path = JSON.parse(pathJson);
            updateHtmlCardElementByPath(path, property, value, skipRender);
        }
        
        function updateHtmlCardElementByPath(path, property, value, skipRender) {
            console.log('updateHtmlCardElementByPath called:', { path, property, value, skipRender });
            
            let current = htmlCardElements;
            
            // Navigate through the path to find the target element
            for (let i = 0; i < path.length - 1; i++) {
                const key = path[i];
                
                if (key === 'children') {
                    // Next key should be the index in children array
                    if (current.children) {
                        current = current.children;
                    }
                } else if (typeof key === 'number') {
                    // Numeric index
                    current = current[key];
                } else {
                    // Property name
                    current = current[key];
                }
            }
            
            // Update the property on the final element
            const lastKey = path[path.length - 1];
            
            if (current && current[lastKey]) {
                current[lastKey][property] = value;
                console.log('Updated element:', current[lastKey]);
                
                // Only re-render if not skipped (e.g., on blur/change, not on input)
                if (!skipRender) {
                    renderHtmlCardCanvas();
                }
            } else {
                console.error('Could not find element at path:', path, 'current:', current);
            }
        }
        
        function removeHtmlCardElementByPathJson(pathJson) {
            const path = JSON.parse(pathJson);
            removeHtmlCardElementByPath(path);
        }
        
        function removeHtmlCardElementByPath(path) {
            let current = htmlCardElements;
            
            // Navigate through the path to find the parent array
            for (let i = 0; i < path.length - 1; i++) {
                const key = path[i];
                if (key === 'children') {
                    // Next key should be the index in children array
                    if (current.children) {
                        current = current.children;
                    }
                } else if (typeof key === 'number') {
                    // Numeric index
                    current = current[key];
                } else {
                    // Property name
                    current = current[key];
                }
            }
            
            // Remove the element at the last index
            const lastKey = path[path.length - 1];
            if (Array.isArray(current) && typeof lastKey === 'number') {
                current.splice(lastKey, 1);
            } else {
                console.error('Could not remove element at path:', path);
            }
            
            renderHtmlCardCanvas();
        }
        
        // Old saveHtmlCard function removed - using new sections-based version above
        
        function parseHtmlCardToElements(cardDataStr) {
            console.log('parseHtmlCardToElements called with:', cardDataStr);
            try {
                const cardData = JSON.parse(cardDataStr);
                console.log('Parsed cardData:', cardData);
                if (cardData.version === 1 && cardData.elements) {
                    htmlCardElements = cardData.elements;
                    console.log('Loaded elements:', htmlCardElements);
                } else {
                    // Legacy or invalid format
                    console.log('Legacy or invalid format, resetting elements');
                    htmlCardElements = [];
                }
            } catch (e) {
                // Invalid JSON, start fresh
                htmlCardElements = [];
            }
        }
        
        function generateHtmlFromElements(elements) {
            let html = '';
            elements.forEach(element => {
                if (element.type === 'heading') {
                    html += `<${element.level}>${element.text}</${element.level}>`;
                } else if (element.type === 'text') {
                    html += `<p>${element.text}</p>`;
                } else if (element.type === 'divider') {
                    html += '<hr>';
                } else if (element.type === 'container') {
                    const layoutClass = element.layout === 'horizontal' ? 'flex-row' : element.layout === 'grid' ? 'grid-2col' : 'flex-col';
                    html += `<div class="container ${layoutClass}"><h4>${element.title}</h4>`;
                    if (element.children && element.children.length > 0) {
                        html += `<div class="container-content">${generateHtmlFromElements(element.children)}</div>`;
                    }
                    html += '</div>';
                } else if (element.type === 'field') {
                    html += `<div class="field"><label>${element.label}:</label> <span>\${field.${element.field}}</span></div>`;
                } else if (element.type === 'step-field') {
                    html += `<div class="field"><label>${element.label}:</label> <span>\$${element.field}</span></div>`;
                }
            });
            return html;
        }
        
        function showAlert(message, type) {
            const alert = document.createElement('div');
            alert.className = `alert ${type}`;
            alert.textContent = message;
            document.body.appendChild(alert);
            setTimeout(() => alert.remove(), 3000);
        }
        
        function copyWebhookUrl(url) {
            navigator.clipboard.writeText(url).then(() => {
                showAlert('Webhook URL gekopieerd naar klembord!', 'alert-success');
            }).catch(err => {
                showAlert('Kopiëren mislukt: ' + err.message, 'alert-error');
            });
        }
        
        // History Functions
        let allHistory = [];
        
        async function loadHistory() {
            console.log('🔍 [DEBUG] loadHistory() started');
            console.log('🔍 [DEBUG] Current URL:', window.location.href);
            try {
                console.log('🔍 [DEBUG] Making API call to /api/history');
                // Call global history API (no formId needed)
                const res = await apiCall(`/api/history`);
                console.log('🔍 [DEBUG] API response status:', res.status);
                const data = await res.json();
                console.log('🔍 [DEBUG] API response data:', data);
                
                // Check if we got an error response
                if (data.error) {
                    throw new Error(data.error);
                }
                
                // Ensure we have an array
                if (!Array.isArray(data)) {
                    console.error('Unexpected API response:', data);
                    throw new Error('API returned invalid data (not an array)');
                }
                
                allHistory = data;
                
                // Populate form filter dropdown with unique form IDs
                const formFilter = document.getElementById('historyFormFilter');
                const uniqueForms = [...new Set(allHistory.map(e => e.formId))].filter(Boolean);
                formFilter.innerHTML = '<option value="">Alle formulieren</option>' + 
                    uniqueForms.map(formId => `<option value="${formId}">Form ${formId}</option>`).join('');
                
                filterHistory();
            } catch (err) {
                console.error('History load error:', err);
                showAlert('Failed to load history: ' + err.message, 'alert-error');
                document.getElementById('historyList').innerHTML = 
                    '<div class="alert alert-error">Failed to load history: ' + escapeHtml(err.message) + '</div>';
                allHistory = []; // Reset to empty array on error
            }
        }
        
        function filterHistory() {
            const statusFilter = document.getElementById('historyStatusFilter')?.value || '';
            const formFilter = document.getElementById('historyFormFilter')?.value || '';
            const dateFilter = document.getElementById('historyDateFilter')?.value || '';
            
            let filtered = allHistory;
            
            // Filter by status
            if (statusFilter) {
                filtered = filtered.filter(entry => entry.status === statusFilter);
            }
            
            // Filter by form ID
            if (formFilter) {
                filtered = filtered.filter(entry => entry.formId === formFilter);
            }
            
            // Filter by date
            if (dateFilter) {
                const filterDate = new Date(dateFilter).toDateString();
                filtered = filtered.filter(entry => {
                    const entryDate = new Date(entry.timestamp).toDateString();
                    return entryDate === filterDate;
                });
            }
            
            renderHistory(filtered);
        }
        
        function renderHistory(history) {
            const container = document.getElementById('historyList');
            
            if (!history || history.length === 0) {
                container.innerHTML = '<div class="alert alert-info">No history entries found</div>';
                return;
            }
            
            // Build table
            container.innerHTML = `
                <div class="overflow-x-auto">
                    <table class="table table-zebra table-sm">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>Tijd</th>
                                <th>Formulier</th>
                                <th>Fout</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${history.map((entry, idx) => {
                                const timestamp = new Date(entry.timestamp);
                                const statusBadge = getStatusBadge(entry.status);
                                const statusColor = getStatusColor(entry.status);
                                const formName = mappings[entry.formId]?.form_name || `Form ${entry.formId}`;
                                
                                return `
                                    <tr>
                                        <td><span class="badge ${statusColor} badge-sm">${statusBadge}</span></td>
                                        <td class="font-mono text-xs">${timestamp.toLocaleString('nl-NL', {dateStyle: 'short', timeStyle: 'medium'})}</td>
                                        <td>
                                            <div class="font-semibold">${escapeHtml(formName)}</div>
                                            <div class="text-xs text-base-content/60">ID: ${entry.formId || 'Unknown'}</div>
                                        </td>
                                        <td class="max-w-xs">
                                            ${entry.error ? `<span class="text-error text-xs">${escapeHtml(entry.error.substring(0, 50))}${entry.error.length > 50 ? '...' : ''}</span>` : '-'}
                                        </td>
                                        <td>
                                            <button class="btn btn-xs btn-ghost" onclick="showHistoryDetail(${idx})">👁️ Bekijk</button>
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
                
                <!-- Detail Modal -->
                <dialog id="historyDetailModal" class="modal">
                    <div class="modal-box max-w-4xl">
                        <h3 class="font-bold text-lg mb-4">Request Details</h3>
                        <div id="historyDetailContent"></div>
                        <div class="modal-action">
                            <form method="dialog">
                                <button class="btn">Sluiten</button>
                            </form>
                        </div>
                    </div>
                    <form method="dialog" class="modal-backdrop">
                        <button>close</button>
                    </form>
                </dialog>
            `;
        }
        
        function showHistoryDetail(idx) {
            const statusFilter = document.getElementById('historyStatusFilter')?.value || '';
            const formFilter = document.getElementById('historyFormFilter')?.value || '';
            const dateFilter = document.getElementById('historyDateFilter')?.value || '';
            
            let filtered = allHistory;
            if (statusFilter) filtered = filtered.filter(entry => entry.status === statusFilter);
            if (formFilter) filtered = filtered.filter(entry => entry.formId === formFilter);
            if (dateFilter) {
                const filterDate = new Date(dateFilter).toDateString();
                filtered = filtered.filter(entry => new Date(entry.timestamp).toDateString() === filterDate);
            }
            
            const entry = filtered[idx];
            if (!entry) return;
            
            const timestamp = new Date(entry.timestamp);
            const statusBadge = getStatusBadge(entry.status);
            const statusColor = getStatusColor(entry.status);
            const formName = mappings[entry.formId]?.form_name || `Form ${entry.formId}`;
            
            document.getElementById('historyDetailContent').innerHTML = `
                <div class="space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <h4 class="font-semibold text-sm mb-1">Status</h4>
                            <span class="badge ${statusColor}">${statusBadge}</span>
                        </div>
                        <div>
                            <h4 class="font-semibold text-sm mb-1">Tijdstip</h4>
                            <div class="text-sm">${timestamp.toLocaleString('nl-NL')}</div>
                        </div>
                        <div>
                            <h4 class="font-semibold text-sm mb-1">Formulier</h4>
                            <div class="text-sm">${escapeHtml(formName)}</div>
                            <div class="text-xs text-base-content/60">ID: ${entry.formId || 'Unknown'}</div>
                        </div>
                    </div>
                    
                    ${entry.error ? `
                    <div>
                        <h4 class="font-semibold text-sm mb-2 text-error flex items-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            Error Details
                        </h4>
                        <div class="alert alert-error text-sm mb-2">
                            <div>
                                <div class="font-semibold">${escapeHtml(entry.error)}</div>
                                ${entry.errorType ? `<div class="text-xs opacity-80 mt-1">Type: ${escapeHtml(entry.errorType)}</div>` : ''}
                            </div>
                        </div>
                        
                        ${entry.invalidField ? `
                        <div class="alert alert-warning mb-2">
                            <div>
                                <div class="font-semibold">❌ Invalid Field: <code class="bg-base-300 px-2 py-1 rounded-badge">${escapeHtml(entry.invalidField)}</code></div>
                                ${entry.hint ? `<div class="text-xs mt-1">${escapeHtml(entry.hint)}</div>` : ''}
                            </div>
                        </div>
                        ` : ''}
                        
                        ${entry.workflowDetails ? `
                        <div class="collapse collapse-arrow bg-base-200 rounded-box mb-2">
                            <input type="checkbox" />
                            <div class="collapse-title">
                                <span class="font-medium">🔧 Workflow Context</span>
                            </div>
                            <div class="collapse-content">
                                <div class="grid grid-cols-2 gap-2">
                                    <div><strong>Step:</strong> ${escapeHtml(entry.workflowDetails.step || 'N/A')}</div>
                                    <div><strong>Model:</strong> ${escapeHtml(entry.workflowDetails.model || 'N/A')}</div>
                                </div>
                            </div>
                        </div>
                        ` : ''}
                        
                        ${entry.odooError ? `
                        <div class="collapse collapse-arrow bg-base-200 rounded-box mb-2">
                            <input type="checkbox" />
                            <div class="collapse-title">
                                <span class="font-medium">🔴 Odoo RPC Error</span>
                            </div>
                            <div class="collapse-content space-y-2">
                                <div><strong>Name:</strong> <code class="bg-base-300 px-2 py-1 rounded-badge">${escapeHtml(entry.odooError.name || 'N/A')}</code></div>
                                <div><strong>Message:</strong> ${escapeHtml(entry.odooError.message || 'N/A')}</div>
                                ${entry.odooError.debug ? `
                                <div>
                                    <strong>Debug Trace:</strong>
                                    <pre class="bg-base-300 p-2 rounded-box overflow-x-auto max-h-48 mt-1 text-xs">${escapeHtml(entry.odooError.debug)}</pre>
                                </div>
                                ` : ''}
                            </div>
                        </div>
                        ` : ''}
                        
                        ${entry.stackTrace ? `
                        <div class="collapse collapse-arrow bg-base-200 rounded-box">
                            <input type="checkbox" />
                            <div class="collapse-title">
                                <span class="font-medium">📋 Stack Trace</span>
                            </div>
                            <div class="collapse-content">
                                <pre class="bg-base-300 p-2 rounded-box text-xs overflow-x-auto max-h-48">${escapeHtml(entry.stackTrace)}</pre>
                            </div>
                        </div>
                        ` : ''}
                    </div>
                    ` : ''}
                    
                    <div>
                        <h4 class="font-semibold text-sm mb-1">Request Data</h4>
                        <pre class="bg-base-300 p-3 rounded-box text-xs overflow-x-auto max-h-64">${JSON.stringify(entry.requestData, null, 2)}</pre>
                    </div>
                    
                    ${entry.workflowResults ? `
                    <div>
                        <h4 class="font-semibold text-sm mb-1">Workflow Results</h4>
                        <pre class="bg-base-300 p-3 rounded-box text-xs overflow-x-auto max-h-64">${JSON.stringify(entry.workflowResults, null, 2)}</pre>
                    </div>
                    ` : ''}
                    
                    ${entry.odooResponse ? `
                    <div>
                        <h4 class="font-semibold text-sm mb-1">Odoo Response</h4>
                        <pre class="bg-base-300 p-3 rounded-box text-xs overflow-x-auto max-h-64">${JSON.stringify(entry.odooResponse, null, 2)}</pre>
                    </div>
                    ` : ''}
                </div>
            `;
            
            document.getElementById('historyDetailModal').showModal();
        }
        
        function getStatusBadge(status) {
            switch(status) {
                case 'success': return '✓ Success';
                case 'error': return '✗ Error';
                case 'skipped': return '⊘ Skipped';
                default: return status;
            }
        }
        
        function getStatusColor(status) {
            switch(status) {
                case 'success': return 'badge-success';
                case 'error': return 'badge-error';
                case 'skipped': return 'badge-warning';
                default: return 'badge-neutral';
            }
        }
    